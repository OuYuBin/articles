/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package shapes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elliptical Shape</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see shapes.ShapesPackage#getEllipticalShape()
 * @model
 * @generated
 */
public interface EllipticalShape extends Shape {
} // EllipticalShape
