package org.example.emfgmfrcp.topicmap.diagram.edit.helpers;

/**
 * @generated
 */
public class TopicMapEditHelper extends TopicMapBaseEditHelper {
}
