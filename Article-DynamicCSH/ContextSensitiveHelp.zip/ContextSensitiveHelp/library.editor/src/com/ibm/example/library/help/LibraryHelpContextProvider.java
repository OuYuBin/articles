package com.ibm.example.library.help;

import org.eclipse.help.HelpSystem;
import org.eclipse.help.IContext;
import org.eclipse.help.IContextProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.TreeSelection;

import com.example.library.Book;
import com.example.library.presentation.LibraryEditor;

public class LibraryHelpContextProvider implements IContextProvider{

	private final LibraryEditor editor;
	
	public LibraryHelpContextProvider(LibraryEditor editor) {
		this.editor = editor;
	}
	
	//Below context are return based upon what is selected in the editor
	//Contexts are built by the HelpSystem provided they have been declared by 
	//extension point
	public IContext getContext(Object target) {
		ISelection selection = editor.getSelection();
		if (selection instanceof TreeSelection) {
			Object element = ((TreeSelection)selection).getFirstElement();
			if (element instanceof Book) {
				return HelpSystem.getContext("library.libraryBookId");
			}
		}		
		return HelpSystem.getContext("library.defaultLibraryId");
	}

	public int getContextChangeMask() {
		return IContextProvider.SELECTION;
	}

	//Here is where dynamic search string values are added
	public String getSearchExpression(Object target) {
		return null;
	}
}
