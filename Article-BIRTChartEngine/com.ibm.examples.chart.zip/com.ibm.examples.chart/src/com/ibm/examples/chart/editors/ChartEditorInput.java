/****************************************************************
 * Licensed Material - Property of IBM
 *
 * ****-*** 
 *
 * (c) Copyright IBM Corp. 2006.  All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 *
 ****************************************************************
 */
package com.ibm.examples.chart.editors;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

import com.ibm.examples.chart.data.DataSet;
import com.ibm.examples.chart.widget.chart.ChartTypeConstants;

/**
 * Describes the input for chart editor. This input contains the chart type, and
 * data.
 * 
 * @author Qi Liang
 */
public class ChartEditorInput implements IEditorInput {

    /**
     * The data set containing the data for chart
     */
    private DataSet dataSet = null;

    /**
     * The chart type
     */
    private int type = ChartTypeConstants.BAR;

    /**
     * Constructor.
     * 
     * @param dataSet
     *            the data set for chart
     * @param type
     *            chart type
     */
    public ChartEditorInput(DataSet dataSet, int type) {
        this.dataSet = dataSet;
        this.type = type;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.IEditorInput#exists()
     */
    public boolean exists() {
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.IEditorInput#getImageDescriptor()
     */
    public ImageDescriptor getImageDescriptor() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.IEditorInput#getName()
     */
    public String getName() {
        return "Chart";
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.IEditorInput#getPersistable()
     */
    public IPersistableElement getPersistable() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.IEditorInput#getToolTipText()
     */
    public String getToolTipText() {
        return "Chart";
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.core.runtime.IAdaptable#getAdapter(java.lang.Class)
     */
    public Object getAdapter(Class adapter) {
        return null;
    }

    /**
     * Gets chart type.
     * 
     * @return chart type.
     */
    public int getType() {
        return type;
    }

    /**
     * Returns the data set.
     * 
     * @return data set
     */
    public DataSet getDataSet() {
        return dataSet;
    }

}
