package org.example.emfgmfrcp.topicmap.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;
import org.example.emfgmfrcp.topicmap.diagram.part.TopicMapDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(TopicMapDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
