package com.ibm.example.familytree;

/**
 * @model
 */
public interface FamilyTree {
	/**
	 * Return a list of contained families
	 * @model type="Family" containment="true" 
	**/
	java.util.List getFamilies();

	/**
	 * Return a list of contained individuals
	 * @model type="Individual" containment="true" 
	**/
	java.util.List getIndividuals();
}
