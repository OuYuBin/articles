/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.editparts;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.gef.EditPolicy;

import shapes.editparts.policies.RectangularShapeComponentEditPolicy;
import shapes.editparts.policies.RectangularShapeDirectEditPolicy;
import shapes.editparts.policies.RectangularShapeGraphicalNodeEditPolicy;
import shapes.editparts.policies.RectangularShapeLayoutEditPolicy;
import shapes.impl.RectangularShapeImpl;

import com.metys.merlin.generation.gef.model.ENode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class RectangularShapeEditPart extends ShapeEditPart{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RectangularShapeEditPart(ENode model, AdapterFactory adapterFactory) {
    super(model, adapterFactory);
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RectangularShapeImpl getRectangularShape() {
    return (RectangularShapeImpl)getENode().getEObject();
  }
  
  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#createFigure()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated   
   */
  protected IFigure createFigure() {
    RectangleFigure figure = new RectangleFigure();
    return figure; 
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getContentPane()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated   
   */
  public IFigure getContentPane() {
    return getFigure(); 
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#refreshVisuals()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void refreshVisuals() {
    // TODO : Implements the figure's visual refresh here.
    // Ensure that you remove @generated or mark it @generated NOT
    RectangleFigure figure = (RectangleFigure) getFigure();
    
    Point loc = getENode().getLocation();
    int w = (int) getENode().getWidth() == 0 ? 30 : (int) getENode().getWidth();
    int h = (int) getENode().getHeight() == 0 ? 30 : (int) getENode().getHeight();
    Dimension size = new Dimension(w, h);
    
    figure.setLocation(loc);
    figure.setSize(size);
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractEditPart#createEditPolicies()
   * <!-- begin-user-doc --> 
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createEditPolicies() {
    // Node Container & Layout Edit Policy
    installEditPolicy(EditPolicy.LAYOUT_ROLE, new RectangularShapeLayoutEditPolicy());
    // Node Component Edit Policy
    installEditPolicy(EditPolicy.COMPONENT_ROLE, new RectangularShapeComponentEditPolicy());
    // Node Direct Edit Policy
    installEditPolicy(EditPolicy.DIRECT_EDIT_ROLE, new RectangularShapeDirectEditPolicy());
    // Node Graphical Node Edit Policy
    installEditPolicy(EditPolicy.GRAPHICAL_NODE_ROLE, new RectangularShapeGraphicalNodeEditPolicy());
  }

}