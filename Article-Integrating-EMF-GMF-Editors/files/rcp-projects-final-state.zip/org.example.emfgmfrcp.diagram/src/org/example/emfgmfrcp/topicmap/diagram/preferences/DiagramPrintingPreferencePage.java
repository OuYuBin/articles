package org.example.emfgmfrcp.topicmap.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.PrintingPreferencePage;
import org.example.emfgmfrcp.topicmap.diagram.part.TopicMapDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramPrintingPreferencePage extends PrintingPreferencePage {

	/**
	 * @generated
	 */
	public DiagramPrintingPreferencePage() {
		setPreferenceStore(TopicMapDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
