package com.sample.application;

import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * The main plugin class to be used in the desktop.
 */
public class SamplePlugin extends AbstractUIPlugin {
	/**
	 * The constructor.
	 */
	public SamplePlugin() {
		super();
	}

}
