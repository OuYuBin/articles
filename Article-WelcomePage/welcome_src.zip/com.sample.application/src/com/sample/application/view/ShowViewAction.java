
package com.sample.application.view;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;

/**
 * A <code>ShowViewAction </code> object is used to show query select view
 * 
 */
public class ShowViewAction extends Action {
	/**
	 * 
	 * <B>Purpose:</B> constructor
	 */
	public ShowViewAction() {
		super();
	}

	/**
	 * 
	 * <B>Purpose:</B> show ViewQuery view
	 * 
	 * @see org.eclipse.jface.action.IAction#run()
	 */
	public void run() {

		IWorkbenchPage workbenchPage = PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getActivePage();

		IViewReference[] ivf = workbenchPage.getViewReferences();

		try {

			int i = ivf.length;
			for (; i-- > 0;) {
				if (ivf[i].getId().equals(
						"com.sample.application.view.DefaultView")) {
					workbenchPage.activate(ivf[i].getView(true));

					break;
				}
			}
		} catch (Exception e1) {

			e1.printStackTrace();
		}

	}

}
