package shorthand;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.Diagnostician;

public class MyEcoreUtil {

	public static boolean isWellFormed(EObject root) {
		Diagnostician diagnostician = new Diagnostician();
		final Diagnostic diagnostic = diagnostician.validate(root);
		boolean res = diagnostic.getSeverity() == Diagnostic.OK;
		return res;
	}

	
}
