/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package shapes.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import shapes.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ShapesFactoryImpl extends EFactoryImpl implements ShapesFactory {
  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ShapesFactoryImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EObject create(EClass eClass) {
    switch (eClass.getClassifierID()) {
      case ShapesPackage.RECTANGULAR_SHAPE: return createRectangularShape();
      case ShapesPackage.ELLIPTICAL_SHAPE: return createEllipticalShape();
      case ShapesPackage.CONNECTION: return createConnection();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RectangularShape createRectangularShape() {
    RectangularShapeImpl rectangularShape = new RectangularShapeImpl();
    return rectangularShape;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EllipticalShape createEllipticalShape() {
    EllipticalShapeImpl ellipticalShape = new EllipticalShapeImpl();
    return ellipticalShape;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Connection createConnection() {
    ConnectionImpl connection = new ConnectionImpl();
    return connection;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ShapesPackage getShapesPackage() {
    return (ShapesPackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  public static ShapesPackage getPackage() {
    return ShapesPackage.eINSTANCE;
  }

} //ShapesFactoryImpl
