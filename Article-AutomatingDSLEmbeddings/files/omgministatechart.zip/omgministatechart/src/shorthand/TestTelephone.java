package shorthand;

import junit.framework.TestCase;
import miniSC.StateMachine;

public class TestTelephone extends TestCase {

	public void testTelephoneExample() {
		StateMachine dslExpr = C.telephoneExample();
		assertTrue(MyEcoreUtil.isWellFormed(dslExpr));
	}

}
