/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package shapes;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see shapes.ShapesFactory
 * @generated
 */
public interface ShapesPackage extends EPackage {
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "shapes";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "null";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "null";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  ShapesPackage eINSTANCE = shapes.impl.ShapesPackageImpl.init();

  /**
   * The meta object id for the '{@link shapes.impl.ShapeImpl <em>Shape</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see shapes.impl.ShapeImpl
   * @see shapes.impl.ShapesPackageImpl#getShape()
   * @generated
   */
  int SHAPE = 0;

  /**
   * The feature id for the '<em><b>X</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SHAPE__X = 0;

  /**
   * The feature id for the '<em><b>Y</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SHAPE__Y = 1;

  /**
   * The feature id for the '<em><b>Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SHAPE__WIDTH = 2;

  /**
   * The feature id for the '<em><b>Height</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SHAPE__HEIGHT = 3;

  /**
   * The feature id for the '<em><b>Source Connections</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SHAPE__SOURCE_CONNECTIONS = 4;

  /**
   * The feature id for the '<em><b>Target Connections</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SHAPE__TARGET_CONNECTIONS = 5;

  /**
   * The number of structural features of the the '<em>Shape</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SHAPE_FEATURE_COUNT = 6;

  /**
   * The meta object id for the '{@link shapes.impl.RectangularShapeImpl <em>Rectangular Shape</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see shapes.impl.RectangularShapeImpl
   * @see shapes.impl.ShapesPackageImpl#getRectangularShape()
   * @generated
   */
  int RECTANGULAR_SHAPE = 1;

  /**
   * The feature id for the '<em><b>X</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RECTANGULAR_SHAPE__X = SHAPE__X;

  /**
   * The feature id for the '<em><b>Y</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RECTANGULAR_SHAPE__Y = SHAPE__Y;

  /**
   * The feature id for the '<em><b>Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RECTANGULAR_SHAPE__WIDTH = SHAPE__WIDTH;

  /**
   * The feature id for the '<em><b>Height</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RECTANGULAR_SHAPE__HEIGHT = SHAPE__HEIGHT;

  /**
   * The feature id for the '<em><b>Source Connections</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RECTANGULAR_SHAPE__SOURCE_CONNECTIONS = SHAPE__SOURCE_CONNECTIONS;

  /**
   * The feature id for the '<em><b>Target Connections</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RECTANGULAR_SHAPE__TARGET_CONNECTIONS = SHAPE__TARGET_CONNECTIONS;

  /**
   * The number of structural features of the the '<em>Rectangular Shape</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RECTANGULAR_SHAPE_FEATURE_COUNT = SHAPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link shapes.impl.EllipticalShapeImpl <em>Elliptical Shape</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see shapes.impl.EllipticalShapeImpl
   * @see shapes.impl.ShapesPackageImpl#getEllipticalShape()
   * @generated
   */
  int ELLIPTICAL_SHAPE = 2;

  /**
   * The feature id for the '<em><b>X</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELLIPTICAL_SHAPE__X = SHAPE__X;

  /**
   * The feature id for the '<em><b>Y</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELLIPTICAL_SHAPE__Y = SHAPE__Y;

  /**
   * The feature id for the '<em><b>Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELLIPTICAL_SHAPE__WIDTH = SHAPE__WIDTH;

  /**
   * The feature id for the '<em><b>Height</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELLIPTICAL_SHAPE__HEIGHT = SHAPE__HEIGHT;

  /**
   * The feature id for the '<em><b>Source Connections</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELLIPTICAL_SHAPE__SOURCE_CONNECTIONS = SHAPE__SOURCE_CONNECTIONS;

  /**
   * The feature id for the '<em><b>Target Connections</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELLIPTICAL_SHAPE__TARGET_CONNECTIONS = SHAPE__TARGET_CONNECTIONS;

  /**
   * The number of structural features of the the '<em>Elliptical Shape</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELLIPTICAL_SHAPE_FEATURE_COUNT = SHAPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link shapes.impl.ConnectionImpl <em>Connection</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see shapes.impl.ConnectionImpl
   * @see shapes.impl.ShapesPackageImpl#getConnection()
   * @generated
   */
  int CONNECTION = 3;

  /**
   * The feature id for the '<em><b>Source</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONNECTION__SOURCE = 0;

  /**
   * The feature id for the '<em><b>Target</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONNECTION__TARGET = 1;

  /**
   * The feature id for the '<em><b>Line Style</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONNECTION__LINE_STYLE = 2;

  /**
   * The number of structural features of the the '<em>Connection</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONNECTION_FEATURE_COUNT = 3;


  /**
   * Returns the meta object for class '{@link shapes.Shape <em>Shape</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Shape</em>'.
   * @see shapes.Shape
   * @generated
   */
  EClass getShape();

  /**
   * Returns the meta object for the attribute '{@link shapes.Shape#getX <em>X</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>X</em>'.
   * @see shapes.Shape#getX()
   * @see #getShape()
   * @generated
   */
  EAttribute getShape_X();

  /**
   * Returns the meta object for the attribute '{@link shapes.Shape#getY <em>Y</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Y</em>'.
   * @see shapes.Shape#getY()
   * @see #getShape()
   * @generated
   */
  EAttribute getShape_Y();

  /**
   * Returns the meta object for the attribute '{@link shapes.Shape#getWidth <em>Width</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Width</em>'.
   * @see shapes.Shape#getWidth()
   * @see #getShape()
   * @generated
   */
  EAttribute getShape_Width();

  /**
   * Returns the meta object for the attribute '{@link shapes.Shape#getHeight <em>Height</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Height</em>'.
   * @see shapes.Shape#getHeight()
   * @see #getShape()
   * @generated
   */
  EAttribute getShape_Height();

  /**
   * Returns the meta object for the containment reference list '{@link shapes.Shape#getSourceConnections <em>Source Connections</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Source Connections</em>'.
   * @see shapes.Shape#getSourceConnections()
   * @see #getShape()
   * @generated
   */
  EReference getShape_SourceConnections();

  /**
   * Returns the meta object for the reference list '{@link shapes.Shape#getTargetConnections <em>Target Connections</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Target Connections</em>'.
   * @see shapes.Shape#getTargetConnections()
   * @see #getShape()
   * @generated
   */
  EReference getShape_TargetConnections();

  /**
   * Returns the meta object for class '{@link shapes.RectangularShape <em>Rectangular Shape</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Rectangular Shape</em>'.
   * @see shapes.RectangularShape
   * @generated
   */
  EClass getRectangularShape();

  /**
   * Returns the meta object for class '{@link shapes.EllipticalShape <em>Elliptical Shape</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Elliptical Shape</em>'.
   * @see shapes.EllipticalShape
   * @generated
   */
  EClass getEllipticalShape();

  /**
   * Returns the meta object for class '{@link shapes.Connection <em>Connection</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Connection</em>'.
   * @see shapes.Connection
   * @generated
   */
  EClass getConnection();

  /**
   * Returns the meta object for the container reference '{@link shapes.Connection#getSource <em>Source</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Source</em>'.
   * @see shapes.Connection#getSource()
   * @see #getConnection()
   * @generated
   */
  EReference getConnection_Source();

  /**
   * Returns the meta object for the reference '{@link shapes.Connection#getTarget <em>Target</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Target</em>'.
   * @see shapes.Connection#getTarget()
   * @see #getConnection()
   * @generated
   */
  EReference getConnection_Target();

  /**
   * Returns the meta object for the attribute '{@link shapes.Connection#getLineStyle <em>Line Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Line Style</em>'.
   * @see shapes.Connection#getLineStyle()
   * @see #getConnection()
   * @generated
   */
  EAttribute getConnection_LineStyle();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  ShapesFactory getShapesFactory();

} //ShapesPackage
