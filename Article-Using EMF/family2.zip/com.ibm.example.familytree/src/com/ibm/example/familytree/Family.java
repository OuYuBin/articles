package com.ibm.example.familytree;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * @model
 */
public interface Family extends EObject {
	/**
	  * Return the father
	  * @return the father
	  * @model
	  **/
	Male getFather();

	/**
	 * Sets the value of the '{@link com.ibm.example.familytree.Family#getFather <em>Father</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Father</em>' reference.
	 * @see #getFather()
	 * @generated
	 */
	void setFather(Male value);

	/**
	 * Return the mother
	 * @return the mother
	 * @model
	 **/
	Female getMother();
	
	
	/**
	 * Sets the value of the '{@link com.ibm.example.familytree.Family#getMother <em>Mother</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mother</em>' reference.
	 * @see #getMother()
	 * @generated
	 */
	void setMother(Female value);

	/**
     * Return children 
     * @return list of child Individuals
     * @model type="Individual" containment="true"
    **/
    EList getChildren();
}
