package org.eclipse.ui.articles.fieldeditors;

import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

/**
 * FieldEditorPreferencePage implementation of ErrorPreferencePage.
 */
public class ErrorsPreferencePage2 
	extends FieldEditorPreferencePage 
	implements IWorkbenchPreferencePage {

	private RadioGroupFieldEditor errors;
	private AddRemoveListFieldEditor list;

	public ErrorsPreferencePage2() {
		super(FieldEditorPreferencePage.GRID);

		// Set the preference store for the preference page.
		IPreferenceStore store =
			HTMLEditorPlugin.getDefault().getPreferenceStore();
		setPreferenceStore(store);
	}
	
	public void createFieldEditors() {
		errors = new RadioGroupFieldEditor(
			IPreferenceConstants.ERRORS_PREFERENCE2,
			"Error conditions",
			1,
			new String[][] {
				{"D&on't show errors",
				 IPreferenceConstants.NO_ERRORS
				},
				{"&Show error if a closing tag is missing", 
				 IPreferenceConstants.ERROR_FOR_MISSING_CLOSING_TAG
				}
			},
			getFieldEditorParent(),
			true);
		addField(errors);		
					
		list = new AddRemoveListFieldEditor(
			IPreferenceConstants.EXEMPT_TAGS_PREFERENCE2,
			"&Tags which do not require closing tags",
			getFieldEditorParent());
		list.setAddButtonText("Add Ta&g");
		list.setRemoveButtonText("&Remove Tag");
		addField(list);
	}

	/**
	 * @see IWorkbenchPreferencePage#init
	 */	
	public void init(IWorkbench wb) {
		// Do nothing.
	}
}
