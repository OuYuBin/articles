imageviwersrc.zip:
==================
This file contains a full source project.

To run the image viewer from source:
====================================
1) unzip the source file into any directory
2) import "Existing Project into Workspace"
3) refresh and update class path
4) build project
5) run as runtime-workbench
6) Window->show view->Other->Sample Category->Image Viewer


Any comments are welcome.

Chengdong Li : cdli@ccs.uky.edu
March 08, 2004