/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.editparts;

import org.eclipse.draw2d.Ellipse;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.gef.EditPolicy;

import shapes.editparts.policies.EllipticalShapeComponentEditPolicy;
import shapes.editparts.policies.EllipticalShapeDirectEditPolicy;
import shapes.editparts.policies.EllipticalShapeGraphicalNodeEditPolicy;
import shapes.editparts.policies.EllipticalShapeLayoutEditPolicy;
import shapes.impl.EllipticalShapeImpl;

import com.metys.merlin.generation.gef.model.ENode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class EllipticalShapeEditPart extends ShapeEditPart{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EllipticalShapeEditPart(ENode model, AdapterFactory adapterFactory) {
    super(model, adapterFactory);
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EllipticalShapeImpl getEllipticalShape() {
    return (EllipticalShapeImpl)getENode().getEObject();
  }
  
  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#createFigure()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated   
   */
  protected IFigure createFigure() {
    Ellipse figure = new Ellipse();
    return figure; 
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getContentPane()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated   
   */
  public IFigure getContentPane() {
    return getFigure(); 
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#refreshVisuals()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void refreshVisuals() {
    // TODO : Implements the figure's visual refresh here.
    // Ensure that you remove @generated or mark it @generated NOT
    Ellipse figure = (Ellipse) getFigure();

    Point loc = getENode().getLocation();
    int w = (int) getENode().getWidth() == 0 ? 30 : (int) getENode().getWidth();
    int h = (int) getENode().getHeight() == 0 ? 30 : (int) getENode().getHeight();
    Dimension size = new Dimension(w, h);
    
    figure.setFill(true);
    figure.setLocation(loc);
    figure.setSize(size);
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractEditPart#createEditPolicies()
   * <!-- begin-user-doc --> 
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createEditPolicies() {
    // Node Container & Layout Edit Policy
    installEditPolicy(EditPolicy.LAYOUT_ROLE, new EllipticalShapeLayoutEditPolicy());
    // Node Component Edit Policy
    installEditPolicy(EditPolicy.COMPONENT_ROLE, new EllipticalShapeComponentEditPolicy());
    // Node Direct Edit Policy
    installEditPolicy(EditPolicy.DIRECT_EDIT_ROLE, new EllipticalShapeDirectEditPolicy());
    // Node Graphical Node Edit Policy
    installEditPolicy(EditPolicy.GRAPHICAL_NODE_ROLE, new EllipticalShapeGraphicalNodeEditPolicy());
  }

}