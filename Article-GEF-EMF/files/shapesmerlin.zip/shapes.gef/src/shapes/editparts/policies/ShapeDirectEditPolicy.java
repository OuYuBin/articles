/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.editparts.policies;

import com.metys.merlin.generation.gef.commands.RenameCommand;

import com.metys.merlin.generation.gef.figures.ENodeFigure;
import com.metys.merlin.generation.gef.figures.EObjectCellEditorLocator;
import com.metys.merlin.generation.gef.figures.EObjectDirectEditManager;

import com.metys.merlin.generation.gef.model.ENode;

import com.metys.merlin.generation.gef.policies.ENodeDirectEditPolicy;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;

import org.eclipse.draw2d.geometry.Point;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.gef.commands.Command;

import org.eclipse.gef.requests.DirectEditRequest;

import org.eclipse.jface.viewers.TextCellEditor;

import shapes.ShapesPackage;

import shapes.editparts.ShapeEditPart;

import shapes.impl.ShapeImpl;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class ShapeDirectEditPolicy extends ENodeDirectEditPolicy{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getDirectEditCommand(DirectEditRequest request) {
    String name = (String) request.getCellEditor().getValue();
    RenameCommand cmd = new RenameCommand((ShapeEditPart)getHost(), name);		
    return cmd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void showCurrentEditValue(DirectEditRequest request) {
    ShapeEditPart hostEditPart = (ShapeEditPart) getHost();
    hostEditPart.refreshVisuals();
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected boolean isDirectEditLocation(Point requestLoc) {
    Point locationCopy = requestLoc.getCopy();
    ShapeEditPart hostEditPart = (ShapeEditPart) getHost();
    IFigure header = ((ENodeFigure) hostEditPart.getFigure()).getHeader();
    header.translateToRelative(locationCopy);
    if (header.containsPoint(locationCopy))
      return true;
    return false;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void performDirectEdit() {
  ShapeEditPart hostEditPart = (ShapeEditPart) getHost();
    Label header = ((ENodeFigure) hostEditPart.getFigure()).getHeader();
    if (manager == null)
      manager = new EObjectDirectEditManager(hostEditPart, TextCellEditor.class, new EObjectCellEditorLocator(header), header);    
    manager.show();
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void handleNodeNameChanged(ENode node, String newName, String oldName) {
    ShapeImpl object = (ShapeImpl) node.getEObject();
    EStructuralFeature labelFeature = 
      ShapesPackage.eINSTANCE.getShape_X(); 
    object.eSet(labelFeature, newName);		
  }
}