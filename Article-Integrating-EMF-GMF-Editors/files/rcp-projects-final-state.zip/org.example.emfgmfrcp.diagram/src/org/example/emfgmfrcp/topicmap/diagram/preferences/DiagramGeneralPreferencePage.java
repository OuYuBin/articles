package org.example.emfgmfrcp.topicmap.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;
import org.example.emfgmfrcp.topicmap.diagram.part.TopicMapDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(TopicMapDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
