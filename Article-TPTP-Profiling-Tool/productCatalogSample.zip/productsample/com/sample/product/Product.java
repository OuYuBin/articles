package com.sample.product;

import java.io.File;

import com.sample.product.util.ProductCatalog;

public class Product {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		if(args.length == 0)
		{
			System.out.println("enter catalog location in this form x:\\path\\Product");
			return;
		}

		Product catalog = new Product();
		catalog.readCatalogFromFolder(args[0]);
	}

	public void readCatalogFromFolder(String name) {
		
		if(name == null)
		{
			System.out.println("invalid folder name");
			return;
		}
		
		File file = new File(name);
		if(!file.exists() || !file.isDirectory())
		{
			System.out.println("invalid folder name " + name);
			return;
		}
		
		ProductCatalog info = new ProductCatalog();
		info.readData(name);
		
		System.out.println(info.getContent());
		
	}

}
