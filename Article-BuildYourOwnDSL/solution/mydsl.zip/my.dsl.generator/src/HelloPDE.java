/* Dummy class for PDE (won't export this plugin otherwise:-() */
class HelloPDE {}