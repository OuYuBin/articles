/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package miniSC.util;

import java.util.HashSet;
import java.util.Map;

import miniSC.MiniSCPackage;
import miniSC.PseudoState;
import miniSC.PseudoStateKind;
import miniSC.Region;
import miniSC.State;
import miniSC.StateMachine;
import miniSC.Transition;
import miniSC.TransitionKind;
import miniSC.Vertex;

import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc --> The <b>Validator</b> for the model. <!-- end-user-doc
 * -->
 * 
 * @see miniSC.MiniSCPackage
 * @generated
 */
public class MiniSCValidator extends EObjectValidator {
	/**
	 * The cached model package <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public static final MiniSCValidator INSTANCE = new MiniSCValidator();

	/**
	 * A constant for the {@link
	 * org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic
	 * {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this
	 * package. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "miniSC";

	/**
	 * A constant with a fixed name that can be used as the base value for
	 * additional hand written constants. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for
	 * additional hand written constants in a derived class. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * The parsed OCL expression for the definition of the '
	 * <em>noDuplicates</em>' invariant constraint. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 */
	private static final String OCL_ANNOTATION_SOURCE = "http://www.eclipse.org/ocl/examples/OCL";

	/**
	 * Creates an instance of the switch. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 */
	public MiniSCValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
		return MiniSCPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresonding classifier of the
	 * model. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
		case MiniSCPackage.STATE_MACHINE:
			return validateStateMachine((StateMachine) value, diagnostics, context);
		case MiniSCPackage.REGION:
			return validateRegion((Region) value, diagnostics, context);
		case MiniSCPackage.VERTEX:
			return validateVertex((Vertex) value, diagnostics, context);
		case MiniSCPackage.TRANSITION:
			return validateTransition((Transition) value, diagnostics, context);
		case MiniSCPackage.PSEUDO_STATE:
			return validatePseudoState((PseudoState) value, diagnostics, context);
		case MiniSCPackage.STATE:
			return validateState((State) value, diagnostics, context);
		case MiniSCPackage.PSEUDO_STATE_KIND:
			return validatePseudoStateKind((PseudoStateKind) value, diagnostics, context);
		case MiniSCPackage.TRANSITION_KIND:
			return validateTransitionKind((TransitionKind) value, diagnostics, context);
		default:
			return true;
		}
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean validateStateMachine(StateMachine stateMachine, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(stateMachine, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean validateRegion(Region region, DiagnosticChain diagnostics, Map<Object, Object> context) {
		boolean result = validate_EveryMultiplicityConforms(region, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(region, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(region, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(region, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(region, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(region, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(region, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateRegion_noDuplicates(region, diagnostics, context);
		return result;
	}

	/**
	 * Validates the noDuplicates constraint of '<em>Region</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean validateRegion_noDuplicates(Region region, DiagnosticChain diagnostics, Map<Object, Object> context) {
		String invName = "noDuplicates";
		/*
		 * self.subVertex->forAll(s1 : Vertex | self.subVertex->forAll(s2 :
		 * Vertex | s1.<>(s2).implies(s1.name.<>(s2.name))))
		 * 
		 * Compiled with http://wiki.eclipse.org/OCLTools
		 */
		Boolean forAll1 = true;
		for (miniSC.Vertex s1 : new HashSet<Vertex>(region.getSubVertex())) {
			if (forAll1) {
				Boolean forAll2 = true;
				for (miniSC.Vertex s2 : new HashSet<Vertex>(region.getSubVertex())) {
					if (forAll2) {
						Boolean notEqual3 = s1 != s2;
						Boolean implies4 = notEqual3;
						if (!(implies4)) {
							implies4 = Boolean.TRUE;
						} else {
							Boolean notEqual5 = !s1.getName().equals(s2.getName());
							implies4 = notEqual5;
						}
						forAll2 = implies4;
					}
				}
				forAll1 = forAll2;
			}
		}

		if (!forAll1) {
			if (diagnostics != null) {
				diagnostics.add(new BasicDiagnostic(Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0, EcorePlugin.INSTANCE.getString(
						"_UI_GenericConstraint_diagnostic", new Object[] { "noDuplicates", getObjectLabel(region, context) }),
						new Object[] { region }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean validateVertex(Vertex vertex, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(vertex, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean validateTransition(Transition transition, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(transition, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean validatePseudoState(PseudoState pseudoState, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(pseudoState, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean validateState(State state, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(state, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean validatePseudoStateKind(PseudoStateKind pseudoStateKind, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean validateTransitionKind(TransitionKind transitionKind, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

} // MiniSCValidator
