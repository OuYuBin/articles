General
=======

This is the readme.txt for the file site_de.leiffrenzel.propertyref_1.0.0.zip 
(an Eclipse feature with functionality for refactoring property keys in Java
Properties files).


License
=======

The software is provided under the terms of the Eclipse Public License (EPL), 
version 1.0. A copy of the EPL is contained in the .zip file. See 
http://eclipse.org/legal/epl-v10.html for the text of the license and 
http://eclipse.org/legal/eplfaq.html for more information about the EPL.


Installation
============

The Eclipse 3.x Platform and JDT are required (both are included in the 
Eclipse SDK available at http://eclipse.org).

To install the feature

- Start Eclipse
- Help > Software Updates > Find and Install 
- Select Search for new features to install > New Archived Site
- Browse to the .zip file
- Finish
- From here it should be self-explaining

The sources of the plugin are included. In order to have a look at them:

- Install the feature (as described above)
- Window > Open Perspective > Plugin Development
- Go to the Plugins View
- Right-click 'de.leiffrenzel.propertyref' > Import > As binary project
- The project is created and the sources can be browsed from the workspace now.


Contact
=======

Leif Frenzel (himself@leiffrenzel.de)