package org.eclipse.ui.articles.fieldeditors;

import org.eclipse.jface.preference.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.*;

/**
 * A preference page for a simple HTML editor.
 */
public class HTMLPreferencePage 
	extends FieldEditorPreferencePage
	implements IWorkbenchPreferencePage {

	public HTMLPreferencePage() {
		super(FieldEditorPreferencePage.GRID);
		
		// Set the preference store for the preference page.
		IPreferenceStore store =
			HTMLEditorPlugin.getDefault().getPreferenceStore();
		setPreferenceStore(store);
	}

	/**
	 * @see org.eclipse.jface.preference.
	 * FieldEditorPreferencePage#createFieldEditors()
	 */
	protected void createFieldEditors() {
		
		// Initialize all field editors.
		BooleanFieldEditor formatOnSave = new BooleanFieldEditor(
			IPreferenceConstants.FORMAT_PREFERENCE, 
			"&Format before saving", 
			getFieldEditorParent());
		addField(formatOnSave);
		
		SpacerFieldEditor spacer1 = new SpacerFieldEditor(
			getFieldEditorParent());
			addField(spacer1);
		
		IntegerFieldEditor indentSpaces = new IntegerFieldEditor(
			IPreferenceConstants.INDENT_PREFERENCE,
			"&Number of spaces to indent:",
			getFieldEditorParent());
		indentSpaces.setValidRange(0, 10);
		addField(indentSpaces);	
		
		SpacerFieldEditor spacer2 = new SpacerFieldEditor(
			getFieldEditorParent());
		addField(spacer2);

		ColorFieldEditor commentColor = new ColorFieldEditor(
			IPreferenceConstants.COMMENT_COLOR_PREFERENCE,
			"C&omments:",
			getFieldEditorParent());
		addField(commentColor);
		ColorFieldEditor errorColor = new ColorFieldEditor(
			IPreferenceConstants.ERROR_COLOR_PREFERENCE,
			"&Errors:",
			getFieldEditorParent());
		addField(errorColor);
		ColorFieldEditor validColor = new ColorFieldEditor(
			IPreferenceConstants.VALID_COLOR_PREFERENCE,
			"&Valid text:",
			getFieldEditorParent());
		addField(validColor);
				
		FontFieldEditor font = new FontFieldEditor(
			IPreferenceConstants.FONT_PREFERENCE,
			"Edito&r font:",
			getFieldEditorParent());
		addField(font);
				
		SpacerFieldEditor spacer3 = new SpacerFieldEditor(
			getFieldEditorParent());
		addField(spacer3);
		
		FileFieldEditor webBrowser = new FileFieldEditor(
			IPreferenceConstants.BROWSER_PREFERENCE,
			"&Web browser:",
			true,
			getFieldEditorParent());
		addField(webBrowser);	
	}
	
	/**
	 * @see IWorkbenchPreferencePage#init
	 */
	public void init(IWorkbench workbench) {
	}
}
