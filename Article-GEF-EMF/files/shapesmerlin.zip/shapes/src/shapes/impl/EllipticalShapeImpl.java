/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package shapes.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.InternalEList;

import shapes.EllipticalShape;
import shapes.ShapesPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elliptical Shape</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class EllipticalShapeImpl extends ShapeImpl implements EllipticalShape {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EllipticalShapeImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return ShapesPackage.eINSTANCE.getEllipticalShape();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ShapesPackage.ELLIPTICAL_SHAPE__SOURCE_CONNECTIONS:
          return ((InternalEList)getSourceConnections()).basicAdd(otherEnd, msgs);
        case ShapesPackage.ELLIPTICAL_SHAPE__TARGET_CONNECTIONS:
          return ((InternalEList)getTargetConnections()).basicAdd(otherEnd, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ShapesPackage.ELLIPTICAL_SHAPE__SOURCE_CONNECTIONS:
          return ((InternalEList)getSourceConnections()).basicRemove(otherEnd, msgs);
        case ShapesPackage.ELLIPTICAL_SHAPE__TARGET_CONNECTIONS:
          return ((InternalEList)getTargetConnections()).basicRemove(otherEnd, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.ELLIPTICAL_SHAPE__X:
        return new Integer(getX());
      case ShapesPackage.ELLIPTICAL_SHAPE__Y:
        return new Integer(getY());
      case ShapesPackage.ELLIPTICAL_SHAPE__WIDTH:
        return new Integer(getWidth());
      case ShapesPackage.ELLIPTICAL_SHAPE__HEIGHT:
        return new Integer(getHeight());
      case ShapesPackage.ELLIPTICAL_SHAPE__SOURCE_CONNECTIONS:
        return getSourceConnections();
      case ShapesPackage.ELLIPTICAL_SHAPE__TARGET_CONNECTIONS:
        return getTargetConnections();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.ELLIPTICAL_SHAPE__X:
        setX(((Integer)newValue).intValue());
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__Y:
        setY(((Integer)newValue).intValue());
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__WIDTH:
        setWidth(((Integer)newValue).intValue());
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__HEIGHT:
        setHeight(((Integer)newValue).intValue());
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__SOURCE_CONNECTIONS:
        getSourceConnections().clear();
        getSourceConnections().addAll((Collection)newValue);
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__TARGET_CONNECTIONS:
        getTargetConnections().clear();
        getTargetConnections().addAll((Collection)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.ELLIPTICAL_SHAPE__X:
        setX(X_EDEFAULT);
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__Y:
        setY(Y_EDEFAULT);
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__WIDTH:
        setWidth(WIDTH_EDEFAULT);
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__HEIGHT:
        setHeight(HEIGHT_EDEFAULT);
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__SOURCE_CONNECTIONS:
        getSourceConnections().clear();
        return;
      case ShapesPackage.ELLIPTICAL_SHAPE__TARGET_CONNECTIONS:
        getTargetConnections().clear();
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.ELLIPTICAL_SHAPE__X:
        return x != X_EDEFAULT;
      case ShapesPackage.ELLIPTICAL_SHAPE__Y:
        return y != Y_EDEFAULT;
      case ShapesPackage.ELLIPTICAL_SHAPE__WIDTH:
        return width != WIDTH_EDEFAULT;
      case ShapesPackage.ELLIPTICAL_SHAPE__HEIGHT:
        return height != HEIGHT_EDEFAULT;
      case ShapesPackage.ELLIPTICAL_SHAPE__SOURCE_CONNECTIONS:
        return sourceConnections != null && !sourceConnections.isEmpty();
      case ShapesPackage.ELLIPTICAL_SHAPE__TARGET_CONNECTIONS:
        return targetConnections != null && !targetConnections.isEmpty();
    }
    return eDynamicIsSet(eFeature);
  }

} //EllipticalShapeImpl
