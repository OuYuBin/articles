
package com.sample.application;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * 
 * A <code> SamplePerspective </code> object is used to generate the initial
 * page layout.
 * 
 */
public class SamplePerspective implements IPerspectiveFactory {

	/**
	 * 
	 * <B>Purpose:</B> Constructor
	 */
	public SamplePerspective() {
	}

	/**
	 * @see org.eclipse.ui.IPerspectiveFactory#createInitialLayout(org.eclipse.ui.IPageLayout)
	 */
	public void createInitialLayout(IPageLayout layout) {

		layout.setEditorAreaVisible(false);
		defineLayout(layout);
	}

	private void defineLayout(IPageLayout layout) {
		// Editors are placed for free.
		String editorArea = layout.getEditorArea();

		layout.setFixed(false);

		// Place navigator and outline to left of
		// editor area.
		IFolderLayout upleft = layout.createFolder("upleft", IPageLayout.LEFT,
				(float) 0.20, editorArea);

		upleft.addView("com.sample.application.view.DefaultView");

	}

}
