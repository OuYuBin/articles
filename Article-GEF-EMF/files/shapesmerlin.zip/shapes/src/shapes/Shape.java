/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package shapes;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Shape</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link shapes.Shape#getX <em>X</em>}</li>
 *   <li>{@link shapes.Shape#getY <em>Y</em>}</li>
 *   <li>{@link shapes.Shape#getWidth <em>Width</em>}</li>
 *   <li>{@link shapes.Shape#getHeight <em>Height</em>}</li>
 *   <li>{@link shapes.Shape#getSourceConnections <em>Source Connections</em>}</li>
 *   <li>{@link shapes.Shape#getTargetConnections <em>Target Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @see shapes.ShapesPackage#getShape()
 * @model abstract="true"
 * @generated
 */
public interface Shape extends EObject{
  /**
   * Returns the value of the '<em><b>X</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>X</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>X</em>' attribute.
   * @see #setX(int)
   * @see shapes.ShapesPackage#getShape_X()
   * @model
   * @generated
   */
  int getX();

  /**
   * Sets the value of the '{@link shapes.Shape#getX <em>X</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>X</em>' attribute.
   * @see #getX()
   * @generated
   */
  void setX(int value);

  /**
   * Returns the value of the '<em><b>Y</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Y</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Y</em>' attribute.
   * @see #setY(int)
   * @see shapes.ShapesPackage#getShape_Y()
   * @model
   * @generated
   */
  int getY();

  /**
   * Sets the value of the '{@link shapes.Shape#getY <em>Y</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Y</em>' attribute.
   * @see #getY()
   * @generated
   */
  void setY(int value);

  /**
   * Returns the value of the '<em><b>Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Width</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Width</em>' attribute.
   * @see #setWidth(int)
   * @see shapes.ShapesPackage#getShape_Width()
   * @model
   * @generated
   */
  int getWidth();

  /**
   * Sets the value of the '{@link shapes.Shape#getWidth <em>Width</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Width</em>' attribute.
   * @see #getWidth()
   * @generated
   */
  void setWidth(int value);

  /**
   * Returns the value of the '<em><b>Height</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Height</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Height</em>' attribute.
   * @see #setHeight(int)
   * @see shapes.ShapesPackage#getShape_Height()
   * @model
   * @generated
   */
  int getHeight();

  /**
   * Sets the value of the '{@link shapes.Shape#getHeight <em>Height</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Height</em>' attribute.
   * @see #getHeight()
   * @generated
   */
  void setHeight(int value);

  /**
   * Returns the value of the '<em><b>Source Connections</b></em>' containment reference list.
   * The list contents are of type {@link shapes.Connection}.
   * It is bidirectional and its opposite is '{@link shapes.Connection#getSource <em>Source</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Source Connections</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Source Connections</em>' containment reference list.
   * @see shapes.ShapesPackage#getShape_SourceConnections()
   * @see shapes.Connection#getSource
   * @model type="shapes.Connection" opposite="source" containment="true"
   * @generated
   */
  EList getSourceConnections();

  /**
   * Returns the value of the '<em><b>Target Connections</b></em>' reference list.
   * The list contents are of type {@link shapes.Connection}.
   * It is bidirectional and its opposite is '{@link shapes.Connection#getTarget <em>Target</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Connections</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Connections</em>' reference list.
   * @see shapes.ShapesPackage#getShape_TargetConnections()
   * @see shapes.Connection#getTarget
   * @model type="shapes.Connection" opposite="target"
   * @generated
   */
  EList getTargetConnections();

} // Shape
