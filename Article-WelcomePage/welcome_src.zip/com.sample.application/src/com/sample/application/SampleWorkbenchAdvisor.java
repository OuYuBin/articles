package com.sample.application;

import org.eclipse.ui.application.IWorkbenchConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchAdvisor;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

/**
 * 
 * A <code> SampleWorkbenchAdvisor </code> object is used for configuring the
 * workbench.
 * 
 */
public class SampleWorkbenchAdvisor extends WorkbenchAdvisor {

	/**
	 * @see org.eclipse.ui.application.WorkbenchAdvisor#getInitialWindowPerspectiveId()
	 */
	public String getInitialWindowPerspectiveId() {
		return "com.sample.application.SamplePerspective";
	}

	/*
	 *  @see org.eclipse.ui.application.WorkbenchAdvisor#initialize
	 */
	public void initialize(IWorkbenchConfigurer configurer) {

		// make sure we always save and restore workspace state
		configurer.setSaveAndRestore(true);
	}

	/**
	 *  @see org.eclipse.ui.application.WorkbenchAdvisor#createWorkbenchWindowAdvisor(org.eclipse.ui.application.IWorkbenchWindowConfigurer)
	 */
	public WorkbenchWindowAdvisor createWorkbenchWindowAdvisor(
			IWorkbenchWindowConfigurer configurer) {
		return new SampleWorkbenchWindowAdvisor(configurer);
	}

}
