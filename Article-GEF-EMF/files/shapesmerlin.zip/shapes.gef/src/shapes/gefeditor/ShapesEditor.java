/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.gefeditor;

import com.metys.merlin.generation.gef.GefPlugin;

import com.metys.merlin.generation.gef.dnd.EObjectLinkTemplateCreationFactory;
import com.metys.merlin.generation.gef.dnd.EObjectTemplateCreationFactory;
import com.metys.merlin.generation.gef.dnd.EReferenceLinkTemplateCreationFactory;

import com.metys.merlin.generation.gef.editor.GEFEditor;
import com.metys.merlin.generation.gef.editor.GEFEditorContextMenuProvider;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.draw2d.ColorConstants;

import org.eclipse.emf.common.notify.AdapterFactory;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;

import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;

import org.eclipse.gef.ContextMenuProvider;
import org.eclipse.gef.EditPartFactory;

import org.eclipse.gef.editparts.ScalableFreeformRootEditPart;

import org.eclipse.gef.palette.CombinedTemplateCreationEntry;
import org.eclipse.gef.palette.ConnectionCreationToolEntry;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteStack;

import org.eclipse.gef.ui.parts.GraphicalViewerKeyHandler;

import org.eclipse.jface.resource.ImageDescriptor;

import shapes.ShapesPackage;

import shapes.editparts.ShapesEditPartFactory;

import shapes.provider.ShapesEditPlugin;
import shapes.provider.ShapesItemProviderAdapterFactory;

/**
 * The ShapesEditor GEF editor.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class ShapesEditor extends GEFEditor {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createComponentsDrawerEntries(PaletteContainer container) {
  	PaletteDrawer drawer = null;
    CombinedTemplateCreationEntry combined = null;
    EClass eClass = null;		    		
    drawer = new PaletteDrawer("<Components>", null);        
    eClass = ShapesPackage.eINSTANCE.getRectangularShape();
    combined = new CombinedTemplateCreationEntry(
  		"RectangularShape",
  		"Create a new RectangularShape",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(ShapesEditPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/RectangularShape.gif")),
  			ImageDescriptor.createFromURL(ShapesEditPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/RectangularShape.gif")));
  	drawer.add(combined);	
    eClass = ShapesPackage.eINSTANCE.getEllipticalShape();
    combined = new CombinedTemplateCreationEntry(
  		"EllipticalShape",
  		"Create a new EllipticalShape",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(ShapesEditPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/EllipticalShape.gif")),
  			ImageDescriptor.createFromURL(ShapesEditPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/EllipticalShape.gif")));
  	drawer.add(combined);	
    if (!drawer.getChildren().isEmpty())
      container.add(drawer);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createClassConnectionEntries(PaletteContainer container) {
    PaletteStack paletteStack = null;
    ConnectionCreationToolEntry tool = null;
    EClass eClass = null;
    paletteStack = new PaletteStack("<Components>", 
        "<Components>",
        ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/group16.gif")));
    eClass = ShapesPackage.eINSTANCE.getConnection();
    tool = new ConnectionCreationToolEntry(
      "Connection",
      "Creating Connection connection",
      new EObjectLinkTemplateCreationFactory(eClass,
        ShapesPackage.eINSTANCE.getConnection_Source(),
        ShapesPackage.eINSTANCE.getConnection_Target()),
      ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/classLink.gif")),
      ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/classLink.gif")));
    paletteStack.add(tool);
    if (!paletteStack.getChildren().isEmpty())
      container.add(paletteStack);    
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createReferenceConnectionEntries(PaletteContainer container) {
    ConnectionCreationToolEntry tool = null;
    EClass eClass = null;
    tool = new ConnectionCreationToolEntry(
  		"Shape 2 Connection",
  		"Creating TargetConnections connection",
  		new EReferenceLinkTemplateCreationFactory(ShapesPackage.eINSTANCE.getShape_TargetConnections()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	container.add(tool);		
    tool = new ConnectionCreationToolEntry(
  		"Shape 2 Connection",
  		"Creating TargetConnections connection",
  		new EReferenceLinkTemplateCreationFactory(ShapesPackage.eINSTANCE.getShape_TargetConnections()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	container.add(tool);				    		
  }  
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Map getTransitionClasses() {
  	Map transitionClasses = new HashMap();
  	List refList = new ArrayList();
    refList.clear();
    refList.add(ShapesPackage.eINSTANCE.getConnection_Source());
    refList.add(ShapesPackage.eINSTANCE.getConnection_Target());
    transitionClasses.put(ShapesPackage.eINSTANCE.getConnection(),
      refList);
    return transitionClasses;
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EditPartFactory createEditPartFactory() {
  	return new ShapesEditPartFactory(createAdapterFactory(), modelResource);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void configureGraphicalViewer() {
    getGraphicalViewer().getControl().setBackground(ColorConstants.listBackground);
    getGraphicalViewer().setRootEditPart(new ScalableFreeformRootEditPart());
    getGraphicalViewer().setEditPartFactory(createEditPartFactory());
    getGraphicalViewer().setKeyHandler(new GraphicalViewerKeyHandler(getGraphicalViewer()).setParent(getCommonKeyHandler()));

    ContextMenuProvider provider 
      = new GEFEditorContextMenuProvider(getGraphicalViewer(), getActionRegistry());
    getGraphicalViewer().setContextMenu(provider);
    getSite().registerContextMenu("ShapesEditor.gef.editor.contextmenu", //$NON-NLS-1$
        provider, getGraphicalViewer());
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AdapterFactory createAdapterFactory() {
    List factories = new ArrayList();
    factories.add(new ResourceItemProviderAdapterFactory());
    factories.add(new ShapesItemProviderAdapterFactory());
    factories.add(new ReflectiveItemProviderAdapterFactory());
    adapterFactory = new ComposedAdapterFactory(factories);
    return adapterFactory;
  }
}