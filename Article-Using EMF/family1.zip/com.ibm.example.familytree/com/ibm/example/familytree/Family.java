package com.ibm.example.familytree;

/**
 * @model
 */
public interface Family {
	/**
	  * Return the father
	  * @return the father
	  * @model
	  **/
	Male getFather();

	/**
	 * Return the mother
	 * @return the mother
	 * @model
	 **/
	Female getMother();
	
	
	/**
     * Return children 
     * @return list of child Individuals
     * @model type="Individual" containment="true"
    **/
    java.util.List getChildren();
}
