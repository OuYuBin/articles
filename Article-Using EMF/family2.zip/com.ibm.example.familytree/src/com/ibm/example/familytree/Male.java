package com.ibm.example.familytree;

/**
 * @model
 */
public interface Male extends Individual {

}
