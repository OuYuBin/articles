/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package example.debug.memoryview.internal.core;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.DebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IRegisterGroup;
import org.eclipse.debug.core.model.IStackFrame;
import org.eclipse.debug.core.model.IThread;
import org.eclipse.debug.core.model.IVariable;

/**
 * 
 *
 */
public class SampleStackFrame extends DebugElement implements IStackFrame {

	private SampleThread fThread;
	private SampleRegisterGroup fRegisterGroup;
	private long timeStamp;
	private String fName;
	
	/**
	 * Constructs a SampleStackFrame
	 * @param thread
	 * @param name
	 */
	public SampleStackFrame(SampleThread thread, String name)
	{
		super(thread.getDebugTarget());
		fThread = thread;
		fName = name;
		timeStamp = System.currentTimeMillis();
	}
	
	public IThread getThread() {
		return fThread;
	}

	public IVariable[] getVariables() throws DebugException {
		
		return new IVariable[]{new SampleVariable(this, "sampleVariable")};
	}

	public boolean hasVariables() throws DebugException {
		return true;
	}

	public Object getAdapter(Class adapter) {
		if (adapter == ILaunch.class)
			return getLaunch();
		return super.getAdapter(adapter);
	}

	public int getLineNumber() throws DebugException {
		return 0;
	}

	public int getCharStart() throws DebugException {
		return 0;
	}

	public int getCharEnd() throws DebugException {
		return 0;
	}

	public String getName() throws DebugException {
		return "[Stackframe:] " + fName + " " + timeStamp;
	}

	public IRegisterGroup[] getRegisterGroups() throws DebugException {
		if (fRegisterGroup == null)
			fRegisterGroup = new SampleRegisterGroup(this);
		return new IRegisterGroup[] {fRegisterGroup};
	}

	public boolean hasRegisterGroups() throws DebugException {
		return true;
	}

	public String getModelIdentifier() {
		return fThread.getModelIdentifier();
	}

	public IDebugTarget getDebugTarget() {
		return fThread.getDebugTarget();
	}

	public ILaunch getLaunch() {
		return fThread.getDebugTarget().getLaunch();
	}

	public boolean canStepInto() {
		return false;
	}

	public boolean canStepOver() {
		return fThread.canStepOver();
	}

	public boolean canStepReturn() {
		return false;
	}

	public boolean isStepping() {
		return false;
	}

	public void stepInto() throws DebugException {

	}

	public void stepOver() throws DebugException {
		fThread.stepOver();
	}

	public void stepReturn() throws DebugException {

	}

	public boolean canResume() {
		return fThread.canResume();
	}

	public boolean canSuspend() {
		return fThread.canSuspend();
	}

	public boolean isSuspended() {
		return fThread.isSuspended();
	}

	public void resume() throws DebugException {
		fThread.resume();

	}

	public void suspend() throws DebugException {
		fThread.suspend();
	}

	public boolean canTerminate() {
		return fThread.canTerminate();
	}

	public boolean isTerminated() {
		return fThread.isTerminated();
	}

	public void terminate() throws DebugException {
		fThread.terminate();

	}
}
