/****************************************************************
 * Licensed Material - Property of IBM
 *
 * ****-*** 
 *
 * (c) Copyright IBM Corp. 2006.  All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 *
 ****************************************************************
 */
package com.ibm.examples.chart.widget.chart;

public class ChartTypeConstants {

    public static final int BAR = 0;

    public static final int MULTI_BAR = 1;

    public static final int LINE = 2;
    
    public static final int PIE = 3;

    public static final int STACKED = 4;
    
    public static final int SCATTER = 5;
    
    public static final int STOCK = 6;
    
    public static final int AREA = 7;
    
    public static final int SAMPLE = 8;
    
    public static final int BAR_WITH_TOOL_TIP = 9;
}
