
This software is provided on an "AS IS" basis and to the maximum extent permitted by applicable law, 
IBM provides the software as is and without faults, and hereby disclaims all other warranties and conditions, either express, 
implied or statutory, including, but not limited to, any (if any) implied warranties, 
duties or conditions of merchantability, of fitness for a particular purpose, of accuracy or completeness of responses, of results, 
of workmanlike effort, of lack of viruses, and of lack of negligence, all with regard to the software.




To run the sample, unzip the file over your eclipse_root directory. The plugin com.xyz.article.wizards will be created.
Restart the workbench.
Run the wizard from the New button, File->New ->Article Wizards menu or from the context menu of a Folder.