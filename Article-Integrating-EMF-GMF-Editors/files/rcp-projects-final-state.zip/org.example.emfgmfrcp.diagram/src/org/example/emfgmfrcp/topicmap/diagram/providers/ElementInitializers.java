package org.example.emfgmfrcp.topicmap.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {
}
