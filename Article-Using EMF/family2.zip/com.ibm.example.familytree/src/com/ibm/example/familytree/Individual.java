package com.ibm.example.familytree;

import org.eclipse.emf.ecore.EObject;

/**
 * @model abstract="true"
 */
public interface Individual extends EObject {
	/**
	 * Return the individuals name.
	 * @return the name
	 * @model
	**/
	String getName();
	/**
	 * Sets the value of the '{@link com.ibm.example.familytree.Individual#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

}
