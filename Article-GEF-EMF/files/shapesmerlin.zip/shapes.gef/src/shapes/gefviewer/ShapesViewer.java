/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.gefviewer;

import com.metys.merlin.generation.gef.viewer.GEFGraphicalViewer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.notify.AdapterFactory;

import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;

import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;

import org.eclipse.gef.EditPartFactory;

import org.eclipse.swt.widgets.Composite;

import shapes.ShapesPackage;

import shapes.editparts.ShapesEditPartFactory;

import shapes.provider.ShapesItemProviderAdapterFactory;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class ShapesViewer extends GEFGraphicalViewer {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private AdapterFactory adapterFactory;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ShapesViewer(Composite parent) {
    super(parent);
  }
    
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AdapterFactory createAdapterFactory() {
    List factories = new ArrayList();
    factories.add(new ResourceItemProviderAdapterFactory());
    factories.add(new ShapesItemProviderAdapterFactory());
    factories.add(new ReflectiveItemProviderAdapterFactory());
    adapterFactory = new ComposedAdapterFactory(factories);
    return adapterFactory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Map getTransitionClasses() {
  	Map transitionClasses = new HashMap();
  	List refList = new ArrayList();
    refList.clear();
    refList.add(ShapesPackage.eINSTANCE.getConnection_Source());
    refList.add(ShapesPackage.eINSTANCE.getConnection_Target());
    transitionClasses.put(ShapesPackage.eINSTANCE.getConnection(),
      refList);
    return transitionClasses;
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EditPartFactory createEditPartFactory() {
  	return new ShapesEditPartFactory(createAdapterFactory(), null);
  }
}