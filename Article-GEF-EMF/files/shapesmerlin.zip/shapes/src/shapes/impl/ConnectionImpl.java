/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package shapes.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EcoreUtil;

import shapes.Connection;
import shapes.Shape;
import shapes.ShapesPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Connection</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link shapes.impl.ConnectionImpl#getSource <em>Source</em>}</li>
 *   <li>{@link shapes.impl.ConnectionImpl#getTarget <em>Target</em>}</li>
 *   <li>{@link shapes.impl.ConnectionImpl#getLineStyle <em>Line Style</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ConnectionImpl extends EObjectImpl implements Connection {
  /**
   * The cached value of the '{@link #getTarget() <em>Target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTarget()
   * @generated
   * @ordered
   */
  protected Shape target = null;

  /**
   * The default value of the '{@link #getLineStyle() <em>Line Style</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLineStyle()
   * @generated
   * @ordered
   */
  protected static final String LINE_STYLE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLineStyle() <em>Line Style</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLineStyle()
   * @generated
   * @ordered
   */
  protected String lineStyle = LINE_STYLE_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ConnectionImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return ShapesPackage.eINSTANCE.getConnection();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Shape getSource() {
    if (eContainerFeatureID != ShapesPackage.CONNECTION__SOURCE) return null;
    return (Shape)eContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSource(Shape newSource) {
    if (newSource != eContainer || (eContainerFeatureID != ShapesPackage.CONNECTION__SOURCE && newSource != null)) {
      if (EcoreUtil.isAncestor(this, newSource))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eContainer != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newSource != null)
        msgs = ((InternalEObject)newSource).eInverseAdd(this, ShapesPackage.SHAPE__SOURCE_CONNECTIONS, Shape.class, msgs);
      msgs = eBasicSetContainer((InternalEObject)newSource, ShapesPackage.CONNECTION__SOURCE, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ShapesPackage.CONNECTION__SOURCE, newSource, newSource));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Shape getTarget() {
    if (target != null && target.eIsProxy()) {
      Shape oldTarget = target;
      target = (Shape)eResolveProxy((InternalEObject)target);
      if (target != oldTarget) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ShapesPackage.CONNECTION__TARGET, oldTarget, target));
      }
    }
    return target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Shape basicGetTarget() {
    return target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetTarget(Shape newTarget, NotificationChain msgs) {
    Shape oldTarget = target;
    target = newTarget;
    if (eNotificationRequired()) {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ShapesPackage.CONNECTION__TARGET, oldTarget, newTarget);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTarget(Shape newTarget) {
    if (newTarget != target) {
      NotificationChain msgs = null;
      if (target != null)
        msgs = ((InternalEObject)target).eInverseRemove(this, ShapesPackage.SHAPE__TARGET_CONNECTIONS, Shape.class, msgs);
      if (newTarget != null)
        msgs = ((InternalEObject)newTarget).eInverseAdd(this, ShapesPackage.SHAPE__TARGET_CONNECTIONS, Shape.class, msgs);
      msgs = basicSetTarget(newTarget, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ShapesPackage.CONNECTION__TARGET, newTarget, newTarget));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLineStyle() {
    return lineStyle;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLineStyle(String newLineStyle) {
    String oldLineStyle = lineStyle;
    lineStyle = newLineStyle;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ShapesPackage.CONNECTION__LINE_STYLE, oldLineStyle, lineStyle));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void reconnect() {
    // TODO: implement this method
    // Ensure that you remove @generated or mark it @generated NOT
    throw new UnsupportedOperationException();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void disconnect() {
    // TODO: implement this method
    // Ensure that you remove @generated or mark it @generated NOT
    throw new UnsupportedOperationException();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void reconnect(Shape source, Shape target) {
    // TODO: implement this method
    // Ensure that you remove @generated or mark it @generated NOT
    throw new UnsupportedOperationException();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ShapesPackage.CONNECTION__SOURCE:
          if (eContainer != null)
            msgs = eBasicRemoveFromContainer(msgs);
          return eBasicSetContainer(otherEnd, ShapesPackage.CONNECTION__SOURCE, msgs);
        case ShapesPackage.CONNECTION__TARGET:
          if (target != null)
            msgs = ((InternalEObject)target).eInverseRemove(this, ShapesPackage.SHAPE__TARGET_CONNECTIONS, Shape.class, msgs);
          return basicSetTarget((Shape)otherEnd, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ShapesPackage.CONNECTION__SOURCE:
          return eBasicSetContainer(null, ShapesPackage.CONNECTION__SOURCE, msgs);
        case ShapesPackage.CONNECTION__TARGET:
          return basicSetTarget(null, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
        case ShapesPackage.CONNECTION__SOURCE:
          return eContainer.eInverseRemove(this, ShapesPackage.SHAPE__SOURCE_CONNECTIONS, Shape.class, msgs);
        default:
          return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.CONNECTION__SOURCE:
        return getSource();
      case ShapesPackage.CONNECTION__TARGET:
        if (resolve) return getTarget();
        return basicGetTarget();
      case ShapesPackage.CONNECTION__LINE_STYLE:
        return getLineStyle();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.CONNECTION__SOURCE:
        setSource((Shape)newValue);
        return;
      case ShapesPackage.CONNECTION__TARGET:
        setTarget((Shape)newValue);
        return;
      case ShapesPackage.CONNECTION__LINE_STYLE:
        setLineStyle((String)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.CONNECTION__SOURCE:
        setSource((Shape)null);
        return;
      case ShapesPackage.CONNECTION__TARGET:
        setTarget((Shape)null);
        return;
      case ShapesPackage.CONNECTION__LINE_STYLE:
        setLineStyle(LINE_STYLE_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.CONNECTION__SOURCE:
        return getSource() != null;
      case ShapesPackage.CONNECTION__TARGET:
        return target != null;
      case ShapesPackage.CONNECTION__LINE_STYLE:
        return LINE_STYLE_EDEFAULT == null ? lineStyle != null : !LINE_STYLE_EDEFAULT.equals(lineStyle);
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (lineStyle: ");
    result.append(lineStyle);
    result.append(')');
    return result.toString();
  }

} //ConnectionImpl
