package org.example.emfgmf.topicmap.diagram.providers;

import org.example.emfgmf.topicmap.diagram.part.TopicMapDiagramEditorPlugin;

/**
 * @generated
 */
public class ElementInitializers {
}
