package org.example.emfgmfrcp.topicmap.diagram.edit.helpers;

/**
 * @generated
 */
public class AssociationEditHelper extends TopicMapBaseEditHelper {
}
