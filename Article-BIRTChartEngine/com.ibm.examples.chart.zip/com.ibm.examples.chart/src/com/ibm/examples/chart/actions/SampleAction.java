/****************************************************************
 * Licensed Material - Property of IBM
 *
 * ****-*** 
 *
 * (c) Copyright IBM Corp. 2006.  All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 *
 ****************************************************************
 */
package com.ibm.examples.chart.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;

import com.ibm.examples.chart.data.DataSet;
import com.ibm.examples.chart.editors.ChartEditorInput;

/**
 * Creates one chart in editor. 
 * 
 * @author Qi Liang
 */
public class SampleAction extends Action {

    private IWorkbenchWindow window;

    /**
     * Chart type
     */
    private int type;

    /**
     * The constructor.
     */
    public SampleAction(IWorkbenchWindow window, int type) {
        this.window = window;
        this.type = type;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.jface.action.IAction#run()
     */
    public void run() {
        try {
            IEditorInput input = new ChartEditorInput(DataSet.getInstance(),
                    type);
            window.getActivePage().openEditor(input,
                    "com.ibm.examples.chart.editors.SampleEditor");
        } catch (PartInitException e) {
            e.printStackTrace();
        }
    }

}