/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.editparts.policies;

import com.metys.merlin.generation.gef.commands.DeleteNodeCommand;

import com.metys.merlin.generation.gef.parts.GraphicalComponentEditPart;

import org.eclipse.gef.commands.Command;

import org.eclipse.gef.requests.GroupRequest;

import shapes.editparts.RectangularShapeEditPart;

import shapes.editparts.policies.ShapeComponentEditPolicy;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class RectangularShapeComponentEditPolicy extends ShapeComponentEditPolicy{
    
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command createDeleteCommand(GroupRequest deleteRequest) {
    Command deleteCmd = new DeleteNodeCommand((GraphicalComponentEditPart) getHost().getParent(), (RectangularShapeEditPart) getHost());
    return deleteCmd;
  }
}