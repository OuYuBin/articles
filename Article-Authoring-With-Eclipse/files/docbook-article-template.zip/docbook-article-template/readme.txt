This directory structure contains everything you need to get started on your article.


Steps
=====

1.	Rename the folder "rename-this-and-work-in-here" to be the name of your article

2.	You should work exclusively in the above folder. 
	Do not add any files to either the main root directory.
	If you have images for your article be sure to place them in your 
	article directory (formerly called rename-this-and-work-in-here) or a subdirectory.

3.	Update the following
	-	<title>....</title> of the article  - this is typically shown in the tile of a web browser
	-	author & company name
	-	date
	-	copyright text in the top right corner

	
4.	Write your content using DocBook. When you have finished, run the article build using Ant.
	In Eclipse, right click on build.xml and select Run As -> Ant Build. To build a PDF
	of your article run Ant with the target build-doc-pdf by selecting 
	Run As - > External Tools... Create a new Ant build and select build-doc-pdf under the
	targets tab.


5.	Remember to include a zip file containing a plug-in(s) with your code.
	This allows readers to quickly try out your examples.

