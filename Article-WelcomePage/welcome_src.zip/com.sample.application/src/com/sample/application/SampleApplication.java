package com.sample.application;

import org.eclipse.core.runtime.IPlatformRunnable;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.application.WorkbenchAdvisor;

/**
 * 
 * A <code> SampleApplication </code> object is used as bootstrap type.
 * 
 */
public class SampleApplication implements IPlatformRunnable {
	private static SampleApplication instance = null;

	/**
	 * 
	 * <B>Purpose:</B> Constructor
	 */
	public SampleApplication() {
		instance = this;
	}

	/**
	 * 
	 * <B>Purpose:</B> initialize workbench advisor
	 * 
	 * @param args
	 *            null for current OSC
	 * @return the return value of the application
	 * 
	 * @see org.eclipse.core.runtime.IPlatformRunnable#run(java.lang.Object)
	 */
	public Object run(Object args) {
		WorkbenchAdvisor workbenchAdvisor = new SampleWorkbenchAdvisor();
		Display display = PlatformUI.createDisplay();

		try {
			int returnCode = PlatformUI.createAndRunWorkbench(display,
					workbenchAdvisor);
			if (returnCode == PlatformUI.RETURN_RESTART) {
				return IPlatformRunnable.EXIT_RESTART;
			} else {
				return IPlatformRunnable.EXIT_OK;
			}
		} finally {
			display.dispose();
		}
	}

	/**
	 * 
	 * <B>Purpose:</B> get the instance of application
	 * 
	 * @return SampleApplication instance
	 */
	public static SampleApplication getDefault() {
		return instance;
	}

	/**
	 * 
	 * <B>Purpose:</B> get workbench instance
	 * 
	 * @return workbench instance
	 */
	public IWorkbench getWorkbench() {
		return PlatformUI.getWorkbench();
	}

}
