/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.editparts.policies;

import com.metys.merlin.generation.gef.commands.DeleteNodeCommand;

import com.metys.merlin.generation.gef.parts.GraphicalComponentEditPart;

import org.eclipse.gef.commands.Command;

import org.eclipse.gef.requests.GroupRequest;

import shapes.editparts.EllipticalShapeEditPart;

import shapes.editparts.policies.ShapeComponentEditPolicy;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class EllipticalShapeComponentEditPolicy extends ShapeComponentEditPolicy{
    
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command createDeleteCommand(GroupRequest deleteRequest) {
    Command deleteCmd = new DeleteNodeCommand((GraphicalComponentEditPart) getHost().getParent(), (EllipticalShapeEditPart) getHost());
    return deleteCmd;
  }
}