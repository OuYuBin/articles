
package org.example.dsl.parser;

import java.io.InputStream;

public class XtextParser extends GenParser {

	public XtextParser(InputStream in) {
		super(in);
	}

}
