package com.sample.application;

import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.ICoolBarManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.ToolBarContributionItem;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

/**
 * 
 * A <code> SampleActionBarAdvisor </code> object is used to create tool bar.
 * 
 */
public class SampleActionBarAdvisor extends ActionBarAdvisor {

	private IWorkbenchAction intro;

	/**
	 * 
	 * <B>Purpose:</B> Constructor
	 * 
	 * @param configurer
	 *            the action bar configurer
	 */
	public SampleActionBarAdvisor(IActionBarConfigurer configurer) {
		super(configurer);

	}

	protected void makeActions(IWorkbenchWindow window) {
		intro = ActionFactory.INTRO.create(window);
	}

	/**
	 * 
	 * <B>Purpose:</B> Fills the menu bar with the main menus for the window.
	 * 
	 * @param menuBar
	 * 
	 * @see org.eclipse.ui.application.ActionBarAdvisor#fillMenuBar(org.eclipse.jface.action.IMenuManager)
	 */
	protected void fillMenuBar(IMenuManager menuBar) {
		menuBar.add(createHelpMenu());
	}

	protected void fillCoolBar(ICoolBarManager coolBar) {
			IToolBarManager toolBar = new ToolBarManager(coolBar.getStyle());
			toolBar.add(new Separator());
			toolBar.add(intro);
			coolBar.add(new ToolBarContributionItem(toolBar,
					"com.sample.application.SimpleToolBar"));
	}

	private MenuManager createHelpMenu() {
		MenuManager menu = new MenuManager(
				"&Help", IWorkbenchActionConstants.M_HELP); //$NON-NLS-1$
		// Welcome or intro page would go here
		menu.add(intro);
		menu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
		return menu;
	}

}
