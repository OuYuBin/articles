package shorthand;

import miniSC.MiniSCExprBuilder;
import miniSC.PseudoState;
import miniSC.Region;
import miniSC.State;
import miniSC.StateMachine;
import miniSC.Transition;

public class C {

	public static StateMachine telephoneExample() {
		State stateIdle = S.state().name("idle").region().toAST();
		PseudoState stateTopInitial = S.pseudoState().name("start").kindInitial().toAST();
		/*
		 * here's where the sub-machine of state Active would be embedded.
		 * That's a total of nine states, one pseudostate, and twelve
		 * transitions. Given that the usage of the expression builder is clear
		 * from the rest of this method, all that is elided.
		 */
		Region regionActive = S.region().subVertex().transition().toAST();
		State stateActive = S.state().name("active").region(regionActive).toAST();
		PseudoState topTerminate = S.pseudoState().name("terminate").kindTerminate().toAST();
		Transition liftReceiver = S.transition().source(stateIdle).target(stateActive).eventID("liftReceiver").action("getDialTone")
				.toAST();
		Transition callerHangsUp = S.transition().source(stateActive).target(stateIdle).eventID("callerHangsUp").action("disconnect")
				.toAST();
		Region topRegion = S.region().subVertex(stateIdle, stateTopInitial, topTerminate).transition().toAST();
		StateMachine telephone = S.stateMachine().region(topRegion).toAST();

		return telephone;
	}

	private static class S extends MiniSCExprBuilder {
	}

}
