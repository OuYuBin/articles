package com.sample.application;

import java.awt.Dimension;

import org.eclipse.swt.graphics.Point;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

/**
 * 
 * A <code>SampleWorkbenchWindowAdvisor  </code> object is used to configure workbench window.
 *
 */
public class SampleWorkbenchWindowAdvisor extends WorkbenchWindowAdvisor {
	private IWorkbenchWindowConfigurer configurer;

	/**
	 *  
	 * <B>Purpose:</B> Constructor
	 * @param configurer an object for configuring the workbench window
	 */
	public SampleWorkbenchWindowAdvisor(IWorkbenchWindowConfigurer configurer) {
		super(configurer);
		this.configurer = configurer;
	}

	/**
	 * 
	 * <B>Purpose:</B> Performs arbitrary actions before the window is opened.
	 *
	 * @see org.eclipse.ui.application.WorkbenchWindowAdvisor#preWindowOpen()
	 */
	public void preWindowOpen() {
		super.preWindowOpen();

		int[] size =getSystemResolution();
		if (size.length != 2 || size[0] < 800 || size[1] < 600)
			configurer.setInitialSize(new Point(800, 600));
		else
			configurer.setInitialSize(new Point(size[0], size[1]));

		configurer.setShowStatusLine(true);
		configurer.setShowFastViewBars(true);
		configurer.setShowCoolBar(true);
		configurer.setShowProgressIndicator(true);

	}
	
	/**
	 * 
	 * <B>Purpose:</B> get the current system resolution
	 * 
	 * @return the width and heigh.
	 */
	public static int[] getSystemResolution() {

		Dimension dimension = java.awt.Toolkit.getDefaultToolkit()
				.getScreenSize();
		int[] res = new int[2];
		res[0] = dimension.width;
		res[1] = dimension.height;
		return res;
	}

	/**
	 * 
	 * <B>Purpose:</B>  Creates a new action bar advisor to configure the action bars of the window
     * via the given action bar configurer.
	 * @param configurer the action bar configurer for the window
	 * @return the action bar advisor for the window
	 *
	 * @see org.eclipse.ui.application.WorkbenchWindowAdvisor#createActionBarAdvisor(org.eclipse.ui.application.IActionBarConfigurer)
	 */
	public ActionBarAdvisor createActionBarAdvisor(
			IActionBarConfigurer configurer) {
		return new SampleActionBarAdvisor(configurer);
	}

	
	
}
