/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package shapes;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connection</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link shapes.Connection#getSource <em>Source</em>}</li>
 *   <li>{@link shapes.Connection#getTarget <em>Target</em>}</li>
 *   <li>{@link shapes.Connection#getLineStyle <em>Line Style</em>}</li>
 * </ul>
 * </p>
 *
 * @see shapes.ShapesPackage#getConnection()
 * @model
 * @generated
 */
public interface Connection extends EObject {
  /**
   * Returns the value of the '<em><b>Source</b></em>' container reference.
   * It is bidirectional and its opposite is '{@link shapes.Shape#getSourceConnections <em>Source Connections</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Source</em>' container reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Source</em>' container reference.
   * @see #setSource(Shape)
   * @see shapes.ShapesPackage#getConnection_Source()
   * @see shapes.Shape#getSourceConnections
   * @model opposite="sourceConnections"
   * @generated
   */
  Shape getSource();

  /**
   * Sets the value of the '{@link shapes.Connection#getSource <em>Source</em>}' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Source</em>' container reference.
   * @see #getSource()
   * @generated
   */
  void setSource(Shape value);

  /**
   * Returns the value of the '<em><b>Target</b></em>' reference.
   * It is bidirectional and its opposite is '{@link shapes.Shape#getTargetConnections <em>Target Connections</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target</em>' reference.
   * @see #setTarget(Shape)
   * @see shapes.ShapesPackage#getConnection_Target()
   * @see shapes.Shape#getTargetConnections
   * @model opposite="targetConnections"
   * @generated
   */
  Shape getTarget();

  /**
   * Sets the value of the '{@link shapes.Connection#getTarget <em>Target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target</em>' reference.
   * @see #getTarget()
   * @generated
   */
  void setTarget(Shape value);

  /**
   * Returns the value of the '<em><b>Line Style</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Line Style</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Line Style</em>' attribute.
   * @see #setLineStyle(String)
   * @see shapes.ShapesPackage#getConnection_LineStyle()
   * @model
   * @generated
   */
  String getLineStyle();

  /**
   * Sets the value of the '{@link shapes.Connection#getLineStyle <em>Line Style</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Line Style</em>' attribute.
   * @see #getLineStyle()
   * @generated
   */
  void setLineStyle(String value);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  void reconnect();

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  void disconnect();

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  void reconnect(Shape source, Shape target);

} // Connection
