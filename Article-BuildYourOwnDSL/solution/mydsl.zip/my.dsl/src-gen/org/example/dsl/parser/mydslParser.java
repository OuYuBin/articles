// $ANTLR 3.0 ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g 2008-05-08 21:52:39

package org.example.dsl.parser;

import org.eclipse.emf.ecore.EObject;

import org.openarchitectureware.xtext.parser.impl.AntlrUtil;
import org.openarchitectureware.xtext.XtextFile;
import org.openarchitectureware.xtext.parser.impl.EcoreModelFactory;
import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.parser.model.ParseTreeManager;
import org.openarchitectureware.xtext.parser.parsetree.Node;

import org.example.dsl.MetaModelRegistration;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class mydslParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_WS", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "'datatype'", "'entity'", "'{'", "'}'"
    };
    public static final int RULE_ML_COMMENT=8;
    public static final int RULE_ID=4;
    public static final int RULE_WS=7;
    public static final int EOF=-1;
    public static final int RULE_INT=6;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=9;

        public mydslParser(TokenStream input) {
            super(input);
            ruleMemo = new HashMap[9+1];
         }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g"; }



    	private Token getLastToken() {
    		return input.LT(-1);
    	}
    	private Token getNextToken() {
    		return input.LT(1);
    	}

    	private int line() {
    		Token t = getNextToken();
    		if (t==null)
    			return 1;
    		return t.getLine();
    	}

    	private int start() {
    		Token t = getNextToken();
    		if (t==null)
    			return 0;
    		if (t instanceof CommonToken) {
    			return ((CommonToken)t).getStartIndex();
    		}
    		return t.getTokenIndex();
    	}

    	private int end() {
    		Token t = getLastToken();
    		if (t==null)
    			return 1;
    		if (t instanceof CommonToken) {
    			return ((CommonToken)t).getStopIndex()+1;
    		}
    		return t.getTokenIndex();
    	}

    	protected Object convert(Object arg) {
    		if (arg instanceof org.antlr.runtime.Token) {
    			Token t = (Token) arg;
    			String s = t.getText();
    			if (t.getType() == mydslLexer.RULE_ID && s.startsWith("^")) {
    				return s.substring(1);
    			} else if (t.getType()==mydslLexer.RULE_STRING) {
    				return s.substring(1,s.length()-1);
    			} else if (t.getType()==mydslLexer.RULE_INT) {
    				return Integer.valueOf(s);
    			}
    			return s;
    		}
    		return arg;
    	}


    	private EcoreModelFactory factory = new EcoreModelFactory(MetaModelRegistration.getEPackage());
        private ParseTreeManager ptm = new ParseTreeManager();
    	private XtextFile xtextfile = MetaModelRegistration.getXtextFile();
    	
    	{
    		
    	}

    	public ParseTreeManager getResult() {
    		return ptm;
    	}

    	private List<ErrorMsg> errors = new ArrayList<ErrorMsg>();
    	public List<ErrorMsg> getErrors() {
    		return errors;
    	}

    	@Override
    		public void reportError(RecognitionException e) {
    		String msg = super.getErrorMessage(e,tokenNames);
    		errors.add(AntlrUtil.create(msg,e,tokenNames));
    			ptm.addError(msg, e);
    			ptm.ruleFinished(null, end());
    		}




    // $ANTLR start parse
    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:121:1: parse returns [Node r] : result= ruleModel EOF ;
    public Node parse() throws RecognitionException {
        Node r = null;
        int parse_StartIndex = input.index();
        EObject result = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 1) ) { return r; }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:122:3: (result= ruleModel EOF )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:122:3: result= ruleModel EOF
            {
            pushFollow(FOLLOW_ruleModel_in_parse67);
            result=ruleModel();
            _fsp--;
            if (failed) return r;
            match(input,EOF,FOLLOW_EOF_in_parse69); if (failed) return r;
            if ( backtracking==0 ) {
              ptm.ruleFinished(result,end());r = ptm.getCurrent();
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 1, parse_StartIndex); }
        }
        return r;
    }
    // $ANTLR end parse


    // $ANTLR start ruleModel
    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:125:1: ruleModel returns [EObject result] : (temp_types= ruleType )* ;
    public EObject ruleModel() throws RecognitionException {
        EObject result = null;
        int ruleModel_StartIndex = input.index();
        EObject temp_types = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 2) ) { return result; }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:126:4: ( (temp_types= ruleType )* )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:126:4: (temp_types= ruleType )*
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "Model");
              				ptm.setModelElement(result);
              			 
            }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:130:1: (temp_types= ruleType )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=10 && LA1_0<=11)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:130:2: temp_types= ruleType
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(((EObject)((EObject)xtextfile.eContents().get(0)).eContents().get(1)),line(),start());
            	    }
            	    pushFollow(FOLLOW_ruleType_in_ruleModel92);
            	    temp_types=ruleType();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      factory.add(result,"types",convert(temp_types),false); ptm.ruleFinished(temp_types,end()); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 2, ruleModel_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleModel


    // $ANTLR start ruleType
    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:134:1: ruleType returns [EObject result] : (temp_datatype= ruleDataType | temp_entity= ruleEntity );
    public EObject ruleType() throws RecognitionException {
        EObject result = null;
        int ruleType_StartIndex = input.index();
        EObject temp_datatype = null;

        EObject temp_entity = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 3) ) { return result; }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:135:9: (temp_datatype= ruleDataType | temp_entity= ruleEntity )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==10) ) {
                alt2=1;
            }
            else if ( (LA2_0==11) ) {
                alt2=2;
            }
            else {
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("134:1: ruleType returns [EObject result] : (temp_datatype= ruleDataType | temp_entity= ruleEntity );", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:135:9: temp_datatype= ruleDataType
                    {
                    pushFollow(FOLLOW_ruleDataType_in_ruleType120);
                    temp_datatype=ruleDataType();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      result =temp_datatype;
                    }

                    }
                    break;
                case 2 :
                    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:135:70: temp_entity= ruleEntity
                    {
                    pushFollow(FOLLOW_ruleEntity_in_ruleType135);
                    temp_entity=ruleEntity();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      result =temp_entity;
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 3, ruleType_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleType


    // $ANTLR start ruleDataType
    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:137:1: ruleDataType returns [EObject result] : ( ( 'datatype' ) (temp_name= RULE_ID ) ) ;
    public EObject ruleDataType() throws RecognitionException {
        EObject result = null;
        int ruleDataType_StartIndex = input.index();
        Token temp_name=null;

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 4) ) { return result; }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:138:4: ( ( ( 'datatype' ) (temp_name= RULE_ID ) ) )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:138:4: ( ( 'datatype' ) (temp_name= RULE_ID ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "DataType");
              				ptm.setModelElement(result);
              			 
            }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:142:1: ( ( 'datatype' ) (temp_name= RULE_ID ) )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:142:2: ( 'datatype' ) (temp_name= RULE_ID )
            {
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:142:2: ( 'datatype' )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:142:3: 'datatype'
            {
            if ( backtracking==0 ) {
              ptm.invokeRule(((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)),line(),start());
            }
            match(input,10,FOLLOW_10_in_ruleDataType158); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:144:1: (temp_name= RULE_ID )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:144:2: temp_name= RULE_ID
            {
            if ( backtracking==0 ) {
              ptm.invokeRule(((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(1)),line(),start());
            }
            temp_name=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleDataType167); if (failed) return result;
            if ( backtracking==0 ) {
              factory.set(result,"name",convert(temp_name),false); ptm.ruleFinished(temp_name,end()); 
            }

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 4, ruleDataType_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleDataType


    // $ANTLR start ruleEntity
    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:149:1: ruleEntity returns [EObject result] : ( ( 'entity' ) (temp_name= RULE_ID ) ( '{' ) (temp_features= ruleFeature )* ( '}' ) ) ;
    public EObject ruleEntity() throws RecognitionException {
        EObject result = null;
        int ruleEntity_StartIndex = input.index();
        Token temp_name=null;
        EObject temp_features = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 5) ) { return result; }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:150:4: ( ( ( 'entity' ) (temp_name= RULE_ID ) ( '{' ) (temp_features= ruleFeature )* ( '}' ) ) )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:150:4: ( ( 'entity' ) (temp_name= RULE_ID ) ( '{' ) (temp_features= ruleFeature )* ( '}' ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "Entity");
              				ptm.setModelElement(result);
              			 
            }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:154:1: ( ( 'entity' ) (temp_name= RULE_ID ) ( '{' ) (temp_features= ruleFeature )* ( '}' ) )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:154:2: ( 'entity' ) (temp_name= RULE_ID ) ( '{' ) (temp_features= ruleFeature )* ( '}' )
            {
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:154:2: ( 'entity' )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:154:3: 'entity'
            {
            if ( backtracking==0 ) {
              ptm.invokeRule(((EObject)((EObject)((EObject)xtextfile.eContents().get(3)).eContents().get(1)).eContents().get(0)),line(),start());
            }
            match(input,11,FOLLOW_11_in_ruleEntity194); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:156:1: (temp_name= RULE_ID )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:156:2: temp_name= RULE_ID
            {
            if ( backtracking==0 ) {
              ptm.invokeRule(((EObject)((EObject)((EObject)xtextfile.eContents().get(3)).eContents().get(1)).eContents().get(1)),line(),start());
            }
            temp_name=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntity203); if (failed) return result;
            if ( backtracking==0 ) {
              factory.set(result,"name",convert(temp_name),false); ptm.ruleFinished(temp_name,end()); 
            }

            }

            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:159:1: ( '{' )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:159:2: '{'
            {
            if ( backtracking==0 ) {
              ptm.invokeRule(((EObject)((EObject)((EObject)xtextfile.eContents().get(3)).eContents().get(1)).eContents().get(2)),line(),start());
            }
            match(input,12,FOLLOW_12_in_ruleEntity212); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:161:1: (temp_features= ruleFeature )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==RULE_ID) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:161:2: temp_features= ruleFeature
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(((EObject)((EObject)((EObject)xtextfile.eContents().get(3)).eContents().get(1)).eContents().get(3)),line(),start());
            	    }
            	    pushFollow(FOLLOW_ruleFeature_in_ruleEntity221);
            	    temp_features=ruleFeature();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      factory.add(result,"features",convert(temp_features),false); ptm.ruleFinished(temp_features,end()); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:164:1: ( '}' )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:164:2: '}'
            {
            if ( backtracking==0 ) {
              ptm.invokeRule(((EObject)((EObject)((EObject)xtextfile.eContents().get(3)).eContents().get(1)).eContents().get(4)),line(),start());
            }
            match(input,13,FOLLOW_13_in_ruleEntity231); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 5, ruleEntity_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleEntity


    // $ANTLR start ruleFeature
    // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:168:1: ruleFeature returns [EObject result] : ( (temp_type= RULE_ID ) (temp_name= RULE_ID ) ) ;
    public EObject ruleFeature() throws RecognitionException {
        EObject result = null;
        int ruleFeature_StartIndex = input.index();
        Token temp_type=null;
        Token temp_name=null;

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 6) ) { return result; }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:169:4: ( ( (temp_type= RULE_ID ) (temp_name= RULE_ID ) ) )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:169:4: ( (temp_type= RULE_ID ) (temp_name= RULE_ID ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "Feature");
              				ptm.setModelElement(result);
              			 
            }
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:173:1: ( (temp_type= RULE_ID ) (temp_name= RULE_ID ) )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:173:2: (temp_type= RULE_ID ) (temp_name= RULE_ID )
            {
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:173:2: (temp_type= RULE_ID )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:173:3: temp_type= RULE_ID
            {
            if ( backtracking==0 ) {
              ptm.invokeRule(((EObject)((EObject)((EObject)xtextfile.eContents().get(4)).eContents().get(1)).eContents().get(0)),line(),start());
            }
            temp_type=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFeature258); if (failed) return result;
            if ( backtracking==0 ) {
              factory.set(result,"type",convert(temp_type),true); ptm.ruleFinished(temp_type,end()); 
            }

            }

            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:177:1: (temp_name= RULE_ID )
            // ..//my.dsl/src-gen//org/example/dsl/parser/mydsl.g:177:2: temp_name= RULE_ID
            {
            if ( backtracking==0 ) {
              ptm.invokeRule(((EObject)((EObject)((EObject)xtextfile.eContents().get(4)).eContents().get(1)).eContents().get(1)),line(),start());
            }
            temp_name=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFeature270); if (failed) return result;
            if ( backtracking==0 ) {
              factory.set(result,"name",convert(temp_name),false); ptm.ruleFinished(temp_name,end()); 
            }

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 6, ruleFeature_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleFeature


 

    public static final BitSet FOLLOW_ruleModel_in_parse67 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_parse69 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleType_in_ruleModel92 = new BitSet(new long[]{0x0000000000000C02L});
    public static final BitSet FOLLOW_ruleDataType_in_ruleType120 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntity_in_ruleType135 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_10_in_ruleDataType158 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleDataType167 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_ruleEntity194 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntity203 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_12_in_ruleEntity212 = new BitSet(new long[]{0x0000000000002010L});
    public static final BitSet FOLLOW_ruleFeature_in_ruleEntity221 = new BitSet(new long[]{0x0000000000002010L});
    public static final BitSet FOLLOW_13_in_ruleEntity231 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFeature258 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFeature270 = new BitSet(new long[]{0x0000000000000002L});

}