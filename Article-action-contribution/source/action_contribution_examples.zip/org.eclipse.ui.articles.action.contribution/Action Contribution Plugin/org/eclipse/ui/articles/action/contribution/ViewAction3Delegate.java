package org.eclipse.ui.articles.action.contribution;

import org.eclipse.jface.action.IAction;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.actions.ActionDelegate;

public class ViewAction3Delegate
	extends ActionDelegate
	implements IViewActionDelegate
{

	/**
	 * @see ActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		// Add your code here to perform the action
	}

	/**
	 * @see IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart view) {
	}

}

