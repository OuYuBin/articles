package org.eclipse.ui.articles.fieldeditors;

import java.util.StringTokenizer;

import org.eclipse.core.resources.*;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.jface.preference.*;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * The main plugin class to be used in the desktop.
 */
public class HTMLEditorPlugin extends AbstractUIPlugin {

	// The shared instance.
	private static HTMLEditorPlugin plugin;

	// Lists of Strings are stored as a single String. This delimiter
	// seperated list items in the single String that is stored.
	private static final String PREFERENCE_DELIMITER = ";";

	/*
	 * The constructor.
	 */
	public HTMLEditorPlugin(IPluginDescriptor descriptor) {
		super(descriptor);
		plugin = this;
	}

	/*
	 * Returns the shared instance.
	 */
	public static HTMLEditorPlugin getDefault() {
		return plugin;
	}

	/*
	 * Returns the workspace instance.
	 */
	public static IWorkspace getWorkspace() {
		return ResourcesPlugin.getWorkspace();
	}

	/**
	 * Initializes a preference store with default preference values 
	 * for this plug-in.
	 * 
	 * @param store the preference store to fill
	 */
	protected void initializeDefaultPreferences(IPreferenceStore store) {
		store.setDefault(IPreferenceConstants.FORMAT_PREFERENCE, true);
		store.setDefault(IPreferenceConstants.INDENT_PREFERENCE, 5);
		PreferenceConverter.setDefault(store, IPreferenceConstants.COMMENT_COLOR_PREFERENCE,  new RGB(0, 200, 125));
		PreferenceConverter.setDefault(store, IPreferenceConstants.ERROR_COLOR_PREFERENCE, new RGB(255, 0, 0));
		PreferenceConverter.setDefault(store, IPreferenceConstants.VALID_COLOR_PREFERENCE,  new RGB(0, 0, 0));
		
		store.setDefault(IPreferenceConstants.EXEMPT_TAGS_PREFERENCE, IPreferenceConstants.EXEMPT_TAGS_DEFAULT);
		store.setDefault(IPreferenceConstants.ERRORS_PREFERENCE, IPreferenceConstants.NO_ERRORS);	

		store.setDefault(IPreferenceConstants.EXEMPT_TAGS_PREFERENCE2, IPreferenceConstants.EXEMPT_TAGS_DEFAULT);
		store.setDefault(IPreferenceConstants.ERRORS_PREFERENCE2, IPreferenceConstants.NO_ERRORS);	
	}
	
	public String[] getDefaultExemptTagsPreference() {
		return convert(getPreferenceStore().getDefaultString(IPreferenceConstants.EXEMPT_TAGS_PREFERENCE));
	}

	public String[] getExemptTagsPreference() {
		return convert(getPreferenceStore().getString(IPreferenceConstants.EXEMPT_TAGS_PREFERENCE));
	}
	
	private String[] convert(String preferenceValue) {
		StringTokenizer tokenizer =
			new StringTokenizer(preferenceValue, PREFERENCE_DELIMITER);
		int tokenCount = tokenizer.countTokens();
		String[] elements = new String[tokenCount];

		for (int i = 0; i < tokenCount; i++) {
			elements[i] = tokenizer.nextToken();
		}

		return elements;
	}

	public void setExemptTagsPreference(String[] elements) {
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < elements.length; i++) {
			buffer.append(elements[i]);
			buffer.append(PREFERENCE_DELIMITER);
		}
		getPreferenceStore().setValue(IPreferenceConstants.EXEMPT_TAGS_PREFERENCE, buffer.toString());
	}

}