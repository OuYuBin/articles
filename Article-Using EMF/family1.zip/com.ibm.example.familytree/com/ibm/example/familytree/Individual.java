package com.ibm.example.familytree;

/**
 * @model abstract="true"
 */
public interface Individual {
	/**
	 * Return the individuals name.
	 * @return the name
	 * @model
	**/
	String getName();
}
