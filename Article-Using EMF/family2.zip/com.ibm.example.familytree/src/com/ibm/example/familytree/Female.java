package com.ibm.example.familytree;

/**
 * @model
 */
public interface Female extends Individual {

}
