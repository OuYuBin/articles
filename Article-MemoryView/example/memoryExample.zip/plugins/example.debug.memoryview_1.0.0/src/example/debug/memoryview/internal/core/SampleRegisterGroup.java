/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package example.debug.memoryview.internal.core;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.DebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IRegister;
import org.eclipse.debug.core.model.IRegisterGroup;

public class SampleRegisterGroup extends DebugElement implements IRegisterGroup {

	SampleRegister fRegister1;
	SampleRegister fRegister2;
	SampleStackFrame fFrame;
	
	public SampleRegisterGroup(SampleStackFrame frame)
	{
		super(frame.getDebugTarget());
		fFrame = frame;
	}
	
	public String getName() throws DebugException {
		return "Register Group";
	}

	public IRegister[] getRegisters() throws DebugException {
		if (fRegister1 == null)
			fRegister1 = new SampleRegister(fFrame, this, "eax");
		
		if (fRegister2 == null)
			fRegister2 = new SampleRegister(fFrame, this, "ebx");
		
		return new IRegister[] {fRegister1, fRegister2};
	}

	public boolean hasRegisters() throws DebugException {
		return true;
	}

	public String getModelIdentifier() {
		return fFrame.getModelIdentifier();
	}

	public IDebugTarget getDebugTarget() {
		return fFrame.getDebugTarget();
	}

	public ILaunch getLaunch() {
		return fFrame.getLaunch();
	}

}
