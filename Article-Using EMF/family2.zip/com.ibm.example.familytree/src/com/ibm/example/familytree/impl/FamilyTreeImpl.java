/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.example.familytree.impl;

import com.ibm.example.familytree.Family;
import com.ibm.example.familytree.FamilyTree;
import com.ibm.example.familytree.FamilytreePackage;
import com.ibm.example.familytree.Individual;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Family Tree</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.example.familytree.impl.FamilyTreeImpl#getFamilies <em>Families</em>}</li>
 *   <li>{@link com.ibm.example.familytree.impl.FamilyTreeImpl#getIndividuals <em>Individuals</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FamilyTreeImpl extends EObjectImpl implements FamilyTree {
	/**
	 * The cached value of the '{@link #getFamilies() <em>Families</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFamilies()
	 * @generated
	 * @ordered
	 */
	protected EList families = null;

	/**
	 * The cached value of the '{@link #getIndividuals() <em>Individuals</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIndividuals()
	 * @generated
	 * @ordered
	 */
	protected EList individuals = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FamilyTreeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return FamilytreePackage.eINSTANCE.getFamilyTree();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getFamilies() {
		if (families == null) {
			families = new EObjectContainmentEList(Family.class, this, FamilytreePackage.FAMILY_TREE__FAMILIES);
		}
		return families;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getIndividuals() {
		if (individuals == null) {
			individuals = new EObjectContainmentEList(Individual.class, this, FamilytreePackage.FAMILY_TREE__INDIVIDUALS);
		}
		return individuals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case FamilytreePackage.FAMILY_TREE__FAMILIES:
					return ((InternalEList)getFamilies()).basicRemove(otherEnd, msgs);
				case FamilytreePackage.FAMILY_TREE__INDIVIDUALS:
					return ((InternalEList)getIndividuals()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case FamilytreePackage.FAMILY_TREE__FAMILIES:
				return getFamilies();
			case FamilytreePackage.FAMILY_TREE__INDIVIDUALS:
				return getIndividuals();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case FamilytreePackage.FAMILY_TREE__FAMILIES:
				getFamilies().clear();
				getFamilies().addAll((Collection)newValue);
				return;
			case FamilytreePackage.FAMILY_TREE__INDIVIDUALS:
				getIndividuals().clear();
				getIndividuals().addAll((Collection)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case FamilytreePackage.FAMILY_TREE__FAMILIES:
				getFamilies().clear();
				return;
			case FamilytreePackage.FAMILY_TREE__INDIVIDUALS:
				getIndividuals().clear();
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case FamilytreePackage.FAMILY_TREE__FAMILIES:
				return families != null && !families.isEmpty();
			case FamilytreePackage.FAMILY_TREE__INDIVIDUALS:
				return individuals != null && !individuals.isEmpty();
		}
		return eDynamicIsSet(eFeature);
	}

} //FamilyTreeImpl
