package org.example.emfgmfrcp.topicmap.diagram.part;

import org.eclipse.gmf.runtime.diagram.ui.parts.DiagramActionBarContributor;

/**
 * @generated
 */
public class TopicMapDiagramActionBarContributor extends
		DiagramActionBarContributor {

	/**
	 * @generated
	 */
	protected Class getEditorClass() {
		return TopicMapDiagramEditor.class;
	}

	/**
	 * @generated
	 */
	protected String getEditorId() {
		return TopicMapDiagramEditor.ID;
	}
}
