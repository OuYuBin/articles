package org.eclipse.ui.articles.fieldeditors;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

/**
 * A preference page for the error-handling 
 * of a simple HTML editor.
 */
public class ErrorsPreferencePage 
	extends PreferencePage 
	implements IWorkbenchPreferencePage {

	private static final int VERTICAL_DIALOG_UNITS_PER_CHAR = 8;
	private static final int LIST_HEIGHT_IN_CHARS = 10;
	private static final int LIST_HEIGHT_IN_DLUS = 
		LIST_HEIGHT_IN_CHARS * VERTICAL_DIALOG_UNITS_PER_CHAR;

	private List exemptTagsList;
	private Text textField;
	private RadioGroupFieldEditor errors;
	private Button removeTag;

	public ErrorsPreferencePage() {
		super();

		// Set the preference store for the preference page.
		IPreferenceStore store =
			HTMLEditorPlugin.getDefault().getPreferenceStore();
		setPreferenceStore(store);
	}

	/**
	 * @see org.eclipse.jface.preference.
	 * PreferencePage#createContents(Composite)
	 */
	protected Control createContents(Composite parent) {
		Composite top = new Composite(parent, SWT.LEFT);

		// Sets the layout data for the top composite's 
		// place in its parent's layout.
		top.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// Sets the layout for the top composite's 
		// children to populate.
		top.setLayout(new GridLayout());
				
		errors = new RadioGroupFieldEditor(
			IPreferenceConstants.ERRORS_PREFERENCE,
			"Error conditions",
			1,
			new String[][] {
				{"D&on't show errors", 
				 IPreferenceConstants.NO_ERRORS
				},
				{"&Show error if a closing tag is missing", 
				 IPreferenceConstants.ERROR_FOR_MISSING_CLOSING_TAG
				}
			},
			top,
			true);
		errors.setPreferencePage(this);
		errors.setPreferenceStore(getPreferenceStore());
		errors.load();
			
		Label listLabel = new Label(top, SWT.NONE);
		listLabel.setText("&Tags which do not require closing tags:");
		
		exemptTagsList = new List(top, SWT.BORDER);
		exemptTagsList.setItems(
			HTMLEditorPlugin.getDefault().getExemptTagsPreference());
	
		// Create a data that takes up the extra space
		// in the dialog and spans both columns.
		GridData listData = new GridData(GridData.FILL_HORIZONTAL);
		listData.heightHint = 
			convertVerticalDLUsToPixels(LIST_HEIGHT_IN_DLUS);
		exemptTagsList.setLayoutData(listData);

		exemptTagsList.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				selectionChanged();
			}
		});
		
		Composite addRemoveGroup = new Composite(top, SWT.NONE);
		addRemoveGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		GridLayout addRemoveLayout = new GridLayout();
		addRemoveLayout.numColumns = 2;
		addRemoveLayout.marginHeight = 0;
		addRemoveLayout.marginWidth = 0;
		addRemoveGroup.setLayout(addRemoveLayout);
		
		// Create a composite for the add and remove buttons.
		Composite buttonGroup = new Composite(addRemoveGroup, SWT.NONE);
		buttonGroup.setLayoutData(new GridData());
		GridLayout buttonLayout = new GridLayout();
		buttonLayout.marginHeight = 0;
		buttonLayout.marginWidth = 0;
		buttonGroup.setLayout(buttonLayout);

		Button addTag = new Button(buttonGroup, SWT.NONE);
		addTag.setText("Add Ta&g");
		addTag.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {	
				addTag();
			}
		});
		GridData addTagData = new GridData(GridData.FILL_HORIZONTAL);
		addTagData.heightHint = convertVerticalDLUsToPixels(IDialogConstants.BUTTON_HEIGHT);
		addTagData.widthHint = convertHorizontalDLUsToPixels(IDialogConstants.BUTTON_WIDTH);
		addTag.setLayoutData(addTagData);	
		
		removeTag = new Button(buttonGroup, SWT.NONE);
		removeTag.setText("&Remove Tag");
		removeTag.setEnabled(false);
		removeTag.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {	
				exemptTagsList.remove(
					exemptTagsList.getSelectionIndex());
				selectionChanged();
			}			
		});
		GridData removeTagData = new GridData(GridData.FILL_HORIZONTAL);
		removeTagData.heightHint = convertVerticalDLUsToPixels(IDialogConstants.BUTTON_HEIGHT);
		removeTagData.widthHint = convertHorizontalDLUsToPixels(IDialogConstants.BUTTON_WIDTH);			
		removeTag.setLayoutData(removeTagData);

		textField = new Text(addRemoveGroup, SWT.BORDER);
		
		GridData textData = new GridData(GridData.FILL_HORIZONTAL);
		textData.verticalAlignment = GridData.BEGINNING;
		textField.setLayoutData(textData);
		
		return top;
	}

	/**
	 * @see IWorkbenchPreferencePage#init
	 */	
	public void init(IWorkbench wb) {	
	}
	
	/*
	 * The user has pressed "Restore defaults".
	 * Restore all default preferences.
	 */
	protected void performDefaults() {
		errors.loadDefault();
		exemptTagsList.setItems(
			HTMLEditorPlugin.getDefault().
				getDefaultExemptTagsPreference());
		// getDefaultExemptTagsPreference() is a convenience
		// method which retrieves the default preference from
		// the preference store.
		super.performDefaults();
	}
	
	/*
	 * The user has pressed Ok or Apply. Store/apply 
	 * this page's values appropriately.
	 */	
	public boolean performOk() {
		errors.store();
		HTMLEditorPlugin.getDefault().
			setExemptTagsPreference(exemptTagsList.getItems());

		return super.performOk();
	}
	
	private void addTag() {
		String tag = textField.getText();
		if (tag != null && tag.length() > 0)
			exemptTagsList.add(tag);
		textField.setText("");
	}
	
	/*
	 * Sets the enablement of the remove button depending
	 * on the selection in the list.
	 */
	private void selectionChanged() {
		int index = exemptTagsList.getSelectionIndex();
		removeTag.setEnabled(index >= 0);		
	}
}
