/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package example.debug.memoryview.internal.core;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.DebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IValue;
import org.eclipse.debug.core.model.IVariable;

public class SampleValue extends DebugElement implements IValue {

	private SampleVariable fVariable;
	
	public SampleValue(SampleVariable variable)
	{
		super(variable.getDebugTarget());
		fVariable = variable;  
	}
	
	public String getReferenceTypeName() throws DebugException {
		return "";
	}

	public String getValueString() throws DebugException {
		return String.valueOf(System.currentTimeMillis());
	}

	public boolean isAllocated() throws DebugException {
		return false;
	}

	public IVariable[] getVariables() throws DebugException {
		return new IVariable[0];
	}

	public boolean hasVariables() throws DebugException {
		return false;
	}

	public String getModelIdentifier() {
		return fVariable.getModelIdentifier();
	}

	public IDebugTarget getDebugTarget() {
		return fVariable.getDebugTarget();
	}

	public ILaunch getLaunch() {
		return fVariable.getLaunch();
	}

}
