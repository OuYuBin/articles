/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package miniSC.impl;

import java.util.Collection;

import miniSC.MiniSCPackage;
import miniSC.Region;
import miniSC.State;
import miniSC.StateMachine;
import miniSC.Transition;
import miniSC.Vertex;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Region</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link miniSC.impl.RegionImpl#getStateMachine <em>State Machine</em>}</li>
 *   <li>{@link miniSC.impl.RegionImpl#getState <em>State</em>}</li>
 *   <li>{@link miniSC.impl.RegionImpl#getSubVertex <em>Sub Vertex</em>}</li>
 *   <li>{@link miniSC.impl.RegionImpl#getTransition <em>Transition</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RegionImpl extends EObjectImpl implements Region {
	/**
	 * The cached value of the '{@link #getSubVertex() <em>Sub Vertex</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubVertex()
	 * @generated
	 * @ordered
	 */
	protected EList<Vertex> subVertex;

	/**
	 * The cached value of the '{@link #getTransition() <em>Transition</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransition()
	 * @generated
	 * @ordered
	 */
	protected EList<Transition> transition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RegionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MiniSCPackage.Literals.REGION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StateMachine getStateMachine() {
		if (eContainerFeatureID != MiniSCPackage.REGION__STATE_MACHINE)
			return null;
		return (StateMachine) eContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStateMachine(StateMachine newStateMachine,
			NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject) newStateMachine,
				MiniSCPackage.REGION__STATE_MACHINE, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStateMachine(StateMachine newStateMachine) {
		if (newStateMachine != eInternalContainer()
				|| (eContainerFeatureID != MiniSCPackage.REGION__STATE_MACHINE && newStateMachine != null)) {
			if (EcoreUtil.isAncestor(this, newStateMachine))
				throw new IllegalArgumentException(
						"Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newStateMachine != null)
				msgs = ((InternalEObject) newStateMachine).eInverseAdd(this,
						MiniSCPackage.STATE_MACHINE__REGION,
						StateMachine.class, msgs);
			msgs = basicSetStateMachine(newStateMachine, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					MiniSCPackage.REGION__STATE_MACHINE, newStateMachine,
					newStateMachine));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State getState() {
		if (eContainerFeatureID != MiniSCPackage.REGION__STATE)
			return null;
		return (State) eContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetState(State newState,
			NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject) newState,
				MiniSCPackage.REGION__STATE, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setState(State newState) {
		if (newState != eInternalContainer()
				|| (eContainerFeatureID != MiniSCPackage.REGION__STATE && newState != null)) {
			if (EcoreUtil.isAncestor(this, newState))
				throw new IllegalArgumentException(
						"Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newState != null)
				msgs = ((InternalEObject) newState).eInverseAdd(this,
						MiniSCPackage.STATE__REGION, State.class, msgs);
			msgs = basicSetState(newState, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					MiniSCPackage.REGION__STATE, newState, newState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Vertex> getSubVertex() {
		if (subVertex == null) {
			subVertex = new EObjectContainmentWithInverseEList<Vertex>(
					Vertex.class, this, MiniSCPackage.REGION__SUB_VERTEX,
					MiniSCPackage.VERTEX__CONTAINER);
		}
		return subVertex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Transition> getTransition() {
		if (transition == null) {
			transition = new EObjectContainmentWithInverseEList<Transition>(
					Transition.class, this, MiniSCPackage.REGION__TRANSITION,
					MiniSCPackage.TRANSITION__CONTAINER);
		}
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd,
			int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MiniSCPackage.REGION__STATE_MACHINE:
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			return basicSetStateMachine((StateMachine) otherEnd, msgs);
		case MiniSCPackage.REGION__STATE:
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			return basicSetState((State) otherEnd, msgs);
		case MiniSCPackage.REGION__SUB_VERTEX:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getSubVertex())
					.basicAdd(otherEnd, msgs);
		case MiniSCPackage.REGION__TRANSITION:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getTransition())
					.basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd,
			int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MiniSCPackage.REGION__STATE_MACHINE:
			return basicSetStateMachine(null, msgs);
		case MiniSCPackage.REGION__STATE:
			return basicSetState(null, msgs);
		case MiniSCPackage.REGION__SUB_VERTEX:
			return ((InternalEList<?>) getSubVertex()).basicRemove(otherEnd,
					msgs);
		case MiniSCPackage.REGION__TRANSITION:
			return ((InternalEList<?>) getTransition()).basicRemove(otherEnd,
					msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(
			NotificationChain msgs) {
		switch (eContainerFeatureID) {
		case MiniSCPackage.REGION__STATE_MACHINE:
			return eInternalContainer().eInverseRemove(this,
					MiniSCPackage.STATE_MACHINE__REGION, StateMachine.class,
					msgs);
		case MiniSCPackage.REGION__STATE:
			return eInternalContainer().eInverseRemove(this,
					MiniSCPackage.STATE__REGION, State.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MiniSCPackage.REGION__STATE_MACHINE:
			return getStateMachine();
		case MiniSCPackage.REGION__STATE:
			return getState();
		case MiniSCPackage.REGION__SUB_VERTEX:
			return getSubVertex();
		case MiniSCPackage.REGION__TRANSITION:
			return getTransition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MiniSCPackage.REGION__STATE_MACHINE:
			setStateMachine((StateMachine) newValue);
			return;
		case MiniSCPackage.REGION__STATE:
			setState((State) newValue);
			return;
		case MiniSCPackage.REGION__SUB_VERTEX:
			getSubVertex().clear();
			getSubVertex().addAll((Collection<? extends Vertex>) newValue);
			return;
		case MiniSCPackage.REGION__TRANSITION:
			getTransition().clear();
			getTransition().addAll((Collection<? extends Transition>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MiniSCPackage.REGION__STATE_MACHINE:
			setStateMachine((StateMachine) null);
			return;
		case MiniSCPackage.REGION__STATE:
			setState((State) null);
			return;
		case MiniSCPackage.REGION__SUB_VERTEX:
			getSubVertex().clear();
			return;
		case MiniSCPackage.REGION__TRANSITION:
			getTransition().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MiniSCPackage.REGION__STATE_MACHINE:
			return getStateMachine() != null;
		case MiniSCPackage.REGION__STATE:
			return getState() != null;
		case MiniSCPackage.REGION__SUB_VERTEX:
			return subVertex != null && !subVertex.isEmpty();
		case MiniSCPackage.REGION__TRANSITION:
			return transition != null && !transition.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //RegionImpl
