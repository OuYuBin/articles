/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package shapes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rectangular Shape</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see shapes.ShapesPackage#getRectangularShape()
 * @model
 * @generated
 */
public interface RectangularShape extends Shape {
} // RectangularShape
