package org.example.emfgmf.topicmap.diagram.edit.helpers;

/**
 * @generated
 */
public class TopicMapEditHelper extends TopicMapBaseEditHelper {
}
