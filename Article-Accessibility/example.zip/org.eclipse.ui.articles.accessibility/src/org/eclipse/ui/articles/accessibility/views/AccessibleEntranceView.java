/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ui.articles.accessibility.views;

import java.net.MalformedURLException;

import org.eclipse.jface.action.*;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.accessibility.AccessibleAdapter;
import org.eclipse.swt.accessibility.AccessibleEvent;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.articles.accessibility.AccessibilityPlugin;
import org.eclipse.ui.part.ViewPart;

/**
 * This is a simple example of a view that is the entrance to
 * a website.
 * 
 */

public class AccessibleEntranceView extends ViewPart {
	private TableViewer viewer;
	private Action resetAction;
	private Action anonymousAction;
	private Text nameEntryField;
	private Text passwordEntryField;

	/**
	 * The constructor.
	 */
	public AccessibleEntranceView() {
	}

	/**
	 * This is where we create out input controls.
	 */
	public void createPartControl(Composite parent) {

		int offset = 5;
		int endOffset = -5;

		Composite workArea = new Composite(parent, SWT.BORDER);
		FormLayout layout = new FormLayout();
		workArea.setLayout(layout);
		Label topLabel = new Label(workArea, SWT.NONE);
		topLabel.setImage(
			AccessibilityPlugin.getDefault().getImageRegistry().get(
				AccessibilityPlugin.WELCOME_IMAGE));

		topLabel
			.getAccessible()
			.addAccessibleListener(new AccessibleAdapter() {
			public void getName(AccessibleEvent e) {
				e.result = "Welcome to our online store!";
			}
		});

		FormData labelData = new FormData();
		labelData.left = new FormAttachment(0, offset);
		labelData.top = new FormAttachment(0, offset);

		topLabel.setLayoutData(labelData);

		Group titleGroup = new Group(workArea, SWT.NONE);
		titleGroup.setText("Enter Name and Password:");

		titleGroup.setFont(JFaceResources.getBannerFont());
		titleGroup.setLayout(new FormLayout());

		labelData = new FormData();
		labelData.left = new FormAttachment(0, offset);
		labelData.right = new FormAttachment(100, endOffset);
		labelData.top = new FormAttachment(topLabel, offset);

		titleGroup.setLayoutData(labelData);

		Label nameTitle = new Label(titleGroup, SWT.NONE);
		nameTitle.setText("&Name:");

		labelData = new FormData();
		labelData.left = new FormAttachment(0, offset);
		labelData.top = new FormAttachment(0, offset);

		nameTitle.setLayoutData(labelData);

		nameEntryField = new Text(titleGroup, SWT.BORDER);

		labelData = new FormData();
		labelData.left = new FormAttachment(30, offset);
		labelData.top = new FormAttachment(0, offset);
		labelData.right = new FormAttachment(100, endOffset);

		nameEntryField.setLayoutData(labelData);

		Label passwordTitle = new Label(titleGroup, SWT.NONE);
		passwordTitle.setText("&Password:");

		labelData = new FormData();
		labelData.left = new FormAttachment(0, offset);
		labelData.top = new FormAttachment(nameEntryField, offset);

		passwordTitle.setLayoutData(labelData);

		passwordEntryField = new Text(titleGroup, SWT.BORDER);

		labelData = new FormData();
		labelData.left = new FormAttachment(30, offset);
		labelData.top = new FormAttachment(nameEntryField, offset);
		labelData.right = new FormAttachment(100, endOffset);

		passwordEntryField.setLayoutData(labelData);

		Button enterButton = new Button(workArea, SWT.PUSH);
		enterButton.setText("&Login");

		labelData = new FormData();
		labelData.top = new FormAttachment(passwordEntryField, offset);
		labelData.left = new FormAttachment(passwordTitle, 0, SWT.LEFT);
		enterButton.setLayoutData(labelData);

		makeActions();
		contributeToActionBars();
	}

	/**
	 * Set the text of the actions.
	 *
	 */
	private void setActionText() {
		resetAction.setText("&Reset Fields");
		anonymousAction.setText("&Anonymous Settings");
	}
	private void makeActions() {
		ImageDescriptor eclipseDescriptor = null;
		try {
			eclipseDescriptor =
				AccessibilityPlugin.getDefault().getImageDescriptor(
					"icons/eclipse.gif");
		} catch (MalformedURLException exception) {
			//If we can't find it don't bother
		}
		resetAction = new Action() {
			public void run() {
				nameEntryField.setText("");
				passwordEntryField.setText("");
			}
		};

		resetAction.setImageDescriptor(eclipseDescriptor);

		anonymousAction = new Action() {
			public void run() {
				nameEntryField.setText("Anonymous");
				passwordEntryField.setText("");
			}
		};
		anonymousAction.setImageDescriptor(eclipseDescriptor);
		setActionText();
	}

	private void contributeToActionBars() {
		IActionBars bars = getViewSite().getActionBars();
		fillLocalPullDown(bars.getMenuManager());
	}

	private void fillLocalPullDown(IMenuManager manager) {
		manager.add(resetAction);
		manager.add(new Separator());
		manager.add(anonymousAction);
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
		nameEntryField.setFocus();
	}
}