/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package miniSC;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Region</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link miniSC.Region#getStateMachine <em>State Machine</em>}</li>
 *   <li>{@link miniSC.Region#getState <em>State</em>}</li>
 *   <li>{@link miniSC.Region#getSubVertex <em>Sub Vertex</em>}</li>
 *   <li>{@link miniSC.Region#getTransition <em>Transition</em>}</li>
 * </ul>
 * </p>
 *
 * @see miniSC.MiniSCPackage#getRegion()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='noDuplicates'"
 *        annotation="http://www.eclipse.org/ocl/examples/OCL noDuplicates='self.subVertex->forAll(s1 : Vertex | \r\n    self.subVertex->forAll(s2 : Vertex | \r\n        s1.<>(s2).implies(s1.name.<>(s2.name))))'"
 * @generated
 */
public interface Region extends EObject {
	/**
	 * Returns the value of the '<em><b>State Machine</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link miniSC.StateMachine#getRegion <em>Region</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State Machine</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State Machine</em>' container reference.
	 * @see #setStateMachine(StateMachine)
	 * @see miniSC.MiniSCPackage#getRegion_StateMachine()
	 * @see miniSC.StateMachine#getRegion
	 * @model opposite="region" transient="false"
	 * @generated
	 */
	StateMachine getStateMachine();

	/**
	 * Sets the value of the '{@link miniSC.Region#getStateMachine <em>State Machine</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State Machine</em>' container reference.
	 * @see #getStateMachine()
	 * @generated
	 */
	void setStateMachine(StateMachine value);

	/**
	 * Returns the value of the '<em><b>State</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link miniSC.State#getRegion <em>Region</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' container reference.
	 * @see #setState(State)
	 * @see miniSC.MiniSCPackage#getRegion_State()
	 * @see miniSC.State#getRegion
	 * @model opposite="region" transient="false"
	 * @generated
	 */
	State getState();

	/**
	 * Sets the value of the '{@link miniSC.Region#getState <em>State</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' container reference.
	 * @see #getState()
	 * @generated
	 */
	void setState(State value);

	/**
	 * Returns the value of the '<em><b>Sub Vertex</b></em>' containment reference list.
	 * The list contents are of type {@link miniSC.Vertex}.
	 * It is bidirectional and its opposite is '{@link miniSC.Vertex#getContainer <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sub Vertex</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sub Vertex</em>' containment reference list.
	 * @see miniSC.MiniSCPackage#getRegion_SubVertex()
	 * @see miniSC.Vertex#getContainer
	 * @model opposite="container" containment="true"
	 * @generated
	 */
	EList<Vertex> getSubVertex();

	/**
	 * Returns the value of the '<em><b>Transition</b></em>' containment reference list.
	 * The list contents are of type {@link miniSC.Transition}.
	 * It is bidirectional and its opposite is '{@link miniSC.Transition#getContainer <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transition</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transition</em>' containment reference list.
	 * @see miniSC.MiniSCPackage#getRegion_Transition()
	 * @see miniSC.Transition#getContainer
	 * @model opposite="container" containment="true"
	 * @generated
	 */
	EList<Transition> getTransition();

} // Region
