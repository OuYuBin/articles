package org.eclipse.ui.articles.badwordchecker;

import java.util.StringTokenizer;

import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * The main plugin class to be used in the desktop.
 */
public class BadWordCheckerPlugin extends AbstractUIPlugin {
	//The shared instance.
	private static BadWordCheckerPlugin plugin;

	//The entry delimiter
	private static String PREFERENCE_DELIMITER = ";";

	//The identifiers for the preferences	
	public static final String BAD_WORDS_PREFERENCE =
		"org.eclipse.ui.articles.badwordchecker.badwords";
	public static final String HIGHLIGHT_PREFERENCE =
		"org.eclipse.ui.articles.badwordchecker.highlight";

	//The default values for the preferences
	public static final String DEFAULT_BAD_WORDS = "bug;bogus;hack;";
	public static final int DEFAULT_HIGHLIGHT = SWT.COLOR_BLUE;

	//The indentifiers for the properties
	public static final String LOCATIONS_PROPERTY =
		"org.eclipse.ui.articles.badwordchecker.locations";

	/**
	 * The constructor.
	 */
	public BadWordCheckerPlugin(IPluginDescriptor descriptor) {
		super(descriptor);
		plugin = this;
	}

	/**
	 * Returns the shared instance.
	 */
	public static BadWordCheckerPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns the workspace instance.
	 */
	public static IWorkspace getWorkspace() {
		return ResourcesPlugin.getWorkspace();
	}

	/** 
	 * Initializes a preference store with default preference values 
	 * for this plug-in.
	 * @param store the preference store to fill
	 */
	protected void initializeDefaultPreferences(IPreferenceStore store) {
		store.setDefault(BAD_WORDS_PREFERENCE, DEFAULT_BAD_WORDS);
		Color color= Display.getDefault().getSystemColor(DEFAULT_HIGHLIGHT);
		PreferenceConverter.setDefault(store,  HIGHLIGHT_PREFERENCE, color.getRGB());

	}
	
	/**
	 * Return the bad words preference default
	 * as an array of Strings.
	 * @return String[]
	 */
	public String[] getDefaultBadWordsPreference(){
		return convert(getPreferenceStore().getDefaultString(BAD_WORDS_PREFERENCE));
	}

	/**
	 * Return the bad words preference as an array of
	 * Strings.
	 * @return String[]
	 */
	public String[] getBadWordsPreference() {
		return convert(getPreferenceStore().getString(BAD_WORDS_PREFERENCE));
	}
	
	/**
	 * Convert the supplied PREFERENCE_DELIMITER delimited
	 * String to a String array.
	 * @return String[]
	 */
	private String[] convert(String preferenceValue) {
		StringTokenizer tokenizer =
			new StringTokenizer(preferenceValue, PREFERENCE_DELIMITER);
		int tokenCount = tokenizer.countTokens();
		String[] elements = new String[tokenCount];

		for (int i = 0; i < tokenCount; i++) {
			elements[i] = tokenizer.nextToken();
		}

		return elements;
	}

	/**
	 * Set the bad words preference
	 * @param String [] elements - the Strings to be 
	 * 	converted to the preference value
	 */
	public void setBadWordsPreference(String[] elements) {
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < elements.length; i++) {
			buffer.append(elements[i]);
			buffer.append(PREFERENCE_DELIMITER);
		}
		getPreferenceStore().setValue(BAD_WORDS_PREFERENCE, buffer.toString());
	}

}