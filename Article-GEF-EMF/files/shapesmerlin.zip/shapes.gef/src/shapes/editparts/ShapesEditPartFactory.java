/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.editparts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;

import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EObjectLink;
import com.metys.merlin.generation.gef.model.EReferenceLink;

import com.metys.merlin.generation.gef.parts.EDiagramEditPart;
import com.metys.merlin.generation.gef.parts.ELinkEditPart;

import org.eclipse.emf.common.notify.AdapterFactory;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.resource.Resource;

import shapes.ShapesPackage;

import shapes.editparts.ConnectionLinkEditPart;
import shapes.editparts.EllipticalShapeEditPart;
import shapes.editparts.RectangularShapeEditPart;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class ShapesEditPartFactory implements EditPartFactory {

  /**
 	 * <!-- begin-user-doc -->
 	 * <!-- end-user-doc -->
 	 * @generated
 	 */
  private AdapterFactory adapterFactory;
  
  /**
 	 * <!-- begin-user-doc -->
 	 * <!-- end-user-doc -->
 	 * @generated
 	 */
  private Resource modelResource;
  
  /**
 	 * <!-- begin-user-doc -->
 	 * <!-- end-user-doc -->
 	 * @generated
 	 */
  public ShapesEditPartFactory(AdapterFactory adapterFactory, Resource modelResource) {
    this.adapterFactory = adapterFactory;
    this.modelResource = modelResource;
  }
  
  /**
   * This creates an edit part for a {@link RectangularShape}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createRectangularShapeEditPart(ENode model)
  {
    return new RectangularShapeEditPart(model, adapterFactory);
  }
  /**
   * This creates an edit part for a {@link EllipticalShape}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createEllipticalShapeEditPart(ENode model)
  {
    return new EllipticalShapeEditPart(model, adapterFactory);
  }

  /**
   * This creates an edit part for a {@link Connection}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createConnectionLinkEditPart(EObjectLink model)
  {
    return new ConnectionLinkEditPart(model, adapterFactory);
  }
  
  /**
   * This creates an edit part for any 
   * model object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createEditPart(EditPart context, Object model) {
    EditPart part = null;
    if (model instanceof EDiagram) {
      part = new EDiagramEditPart((EDiagram) model, adapterFactory, modelResource);
    } else if (model instanceof EReferenceLink) {
      part = new ELinkEditPart((EReferenceLink) model, adapterFactory);
    }	else if (model instanceof EObjectLink) {
      EClass ecoreClass = ((EObjectLink)model).getTransitionEObject().eClass();						
      if (ecoreClass == ShapesPackage.eINSTANCE.getConnection())
        part = createConnectionLinkEditPart((EObjectLink) model);
    } else if (model instanceof ENode){
      EClass ecoreClass = ((ENode)model).getEObject().eClass();
      if (ecoreClass == ShapesPackage.eINSTANCE.getRectangularShape())
        part = createRectangularShapeEditPart((ENode) model);
      if (ecoreClass == ShapesPackage.eINSTANCE.getEllipticalShape())
        part = createEllipticalShapeEditPart((ENode) model);
    }
    return part;
  }	
}