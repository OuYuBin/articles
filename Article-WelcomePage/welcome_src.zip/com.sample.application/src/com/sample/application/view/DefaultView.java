
package com.sample.application.view;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

/**
 * TODO A <code> </code> object is used to
 * 
 */
public class DefaultView extends ViewPart {

	public void createPartControl(Composite parent) {
		Composite top = new Composite(parent, SWT.BORDER);
		top.setLayout(new GridLayout());

		Label label = new Label(top, SWT.NONE);
		label.setText("a sample view");

	}

	public void setFocus() {
		// do nothing here
	}

}
