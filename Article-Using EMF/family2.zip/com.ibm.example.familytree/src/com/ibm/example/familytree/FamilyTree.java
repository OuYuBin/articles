package com.ibm.example.familytree;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * @model
 */
public interface FamilyTree extends EObject {
	/**
	 * Return a list of contained families
	 * @model type="Family" containment="true" 
	**/
	EList getFamilies();

	/**
	 * Return a list of contained individuals
	 * @model type="Individual" containment="true" 
	**/
	EList getIndividuals();
}
