package miniSC;

public class MiniSCExprBuilder {
	public static StateMachineBeingBuilt stateMachine() {
		return new StateMachineBeingBuilt(miniSC.MiniSCFactory.eINSTANCE.createStateMachine());
	}

	public static RegionBeingBuilt0 region() {
		return new RegionBeingBuilt(miniSC.MiniSCFactory.eINSTANCE.createRegion());
	}

	public static TransitionBeingBuilt0 transition() {
		return new TransitionBeingBuilt(miniSC.MiniSCFactory.eINSTANCE.createTransition());
	}

	public static PseudoStateBeingBuilt0 pseudoState() {
		return new PseudoStateBeingBuilt(miniSC.MiniSCFactory.eINSTANCE.createPseudoState());
	}

	public static StateBeingBuilt0 state() {
		return new StateBeingBuilt(miniSC.MiniSCFactory.eINSTANCE.createState());
	}

	public static class StateMachineBeingBuilt {
		private final miniSC.StateMachine myExpr;

		public miniSC.StateMachine toAST() {
			return this.myExpr;
		}

		StateMachineBeingBuilt(miniSC.StateMachine arg) {
			this.myExpr = arg;
		}

		public StateMachineBeingBuilt region(miniSC.Region... items) {
			this.myExpr.getRegion().clear();
			this.myExpr.getRegion().addAll(java.util.Arrays.asList(items));
			return this;
		}
	}

	public static class RegionBeingBuilt implements RegionBeingBuilt0, RegionBeingBuilt1, RegionBeingBuilt2 {
		private final miniSC.Region myExpr;

		public miniSC.Region toAST() {
			return this.myExpr;
		}

		RegionBeingBuilt(miniSC.Region arg) {
			this.myExpr = arg;
		}

		public RegionBeingBuilt1 subVertex(miniSC.Vertex... items) {
			this.myExpr.getSubVertex().clear();
			this.myExpr.getSubVertex().addAll(java.util.Arrays.asList(items));
			return this;
		}

		public RegionBeingBuilt2 transition(miniSC.Transition... items) {
			this.myExpr.getTransition().clear();
			this.myExpr.getTransition().addAll(java.util.Arrays.asList(items));
			return this;
		}
	}

	public interface RegionBeingBuilt0 {
		public RegionBeingBuilt1 subVertex(miniSC.Vertex... items);
	}

	public interface RegionBeingBuilt1 {
		public RegionBeingBuilt2 transition(miniSC.Transition... items);
	}

	public interface RegionBeingBuilt2 {
		public miniSC.Region toAST();
	}

	public static class TransitionBeingBuilt implements TransitionBeingBuilt0, TransitionBeingBuilt1, TransitionBeingBuilt2,
			TransitionBeingBuilt3 {
		private final miniSC.Transition myExpr;

		public miniSC.Transition toAST() {
			return this.myExpr;
		}

		TransitionBeingBuilt(miniSC.Transition arg) {
			this.myExpr = arg;
		}

		public TransitionBeingBuilt1 source(miniSC.Vertex arg) {
			this.myExpr.setSource(arg);
			return this;
		}

		public TransitionBeingBuilt2 target(miniSC.Vertex arg) {
			this.myExpr.setTarget(arg);
			return this;
		}

		public TransitionBeingBuilt2 kindInternal() {
			this.myExpr.setKind(miniSC.TransitionKind.INTERNAL);
			return this;
		}

		public TransitionBeingBuilt2 kindLocal() {
			this.myExpr.setKind(miniSC.TransitionKind.LOCAL);
			return this;
		}

		public TransitionBeingBuilt2 kindExternal() {
			this.myExpr.setKind(miniSC.TransitionKind.EXTERNAL);
			return this;
		}

		public TransitionBeingBuilt3 eventID(java.lang.String arg) {
			this.myExpr.setEventID(arg);
			return this;
		}

		public TransitionBeingBuilt3 condition(java.lang.String arg) {
			this.myExpr.setCondition(arg);
			return this;
		}

		public TransitionBeingBuilt3 action(java.lang.String arg) {
			this.myExpr.setAction(arg);
			return this;
		}
	}

	public interface TransitionBeingBuilt0 {
		public TransitionBeingBuilt1 source(miniSC.Vertex arg);
	}

	public interface TransitionBeingBuilt1 {
		public TransitionBeingBuilt2 target(miniSC.Vertex arg);
	}

	public interface TransitionBeingBuilt2 {

		public TransitionBeingBuilt2 kindInternal();

		public TransitionBeingBuilt2 kindLocal();

		public TransitionBeingBuilt2 kindExternal();

		public TransitionBeingBuilt3 eventID(java.lang.String arg);
	}

	public interface TransitionBeingBuilt3 {
		public TransitionBeingBuilt3 condition(java.lang.String arg);

		public TransitionBeingBuilt3 action(java.lang.String arg);

		/* allModdersAreOptional */
		public miniSC.Transition toAST();
	}

	public static class PseudoStateBeingBuilt implements PseudoStateBeingBuilt0, PseudoStateBeingBuilt1 {
		private final miniSC.PseudoState myExpr;

		public miniSC.PseudoState toAST() {
			return this.myExpr;
		}

		PseudoStateBeingBuilt(miniSC.PseudoState arg) {
			this.myExpr = arg;
		}

		public PseudoStateBeingBuilt1 name(java.lang.String arg) {
			this.myExpr.setName(arg);
			return this;
		}

		public PseudoStateBeingBuilt1 kindInitial() {
			this.myExpr.setKind(miniSC.PseudoStateKind.INITIAL);
			return this;
		}

		public PseudoStateBeingBuilt1 kindDeepHistory() {
			this.myExpr.setKind(miniSC.PseudoStateKind.DEEP_HISTORY);
			return this;
		}

		public PseudoStateBeingBuilt1 kindShallowHistory() {
			this.myExpr.setKind(miniSC.PseudoStateKind.SHALLOW_HISTORY);
			return this;
		}

		public PseudoStateBeingBuilt1 kindJoin() {
			this.myExpr.setKind(miniSC.PseudoStateKind.JOIN);
			return this;
		}

		public PseudoStateBeingBuilt1 kindFork() {
			this.myExpr.setKind(miniSC.PseudoStateKind.FORK);
			return this;
		}

		public PseudoStateBeingBuilt1 kindJunction() {
			this.myExpr.setKind(miniSC.PseudoStateKind.JUNCTION);
			return this;
		}

		public PseudoStateBeingBuilt1 kindChoice() {
			this.myExpr.setKind(miniSC.PseudoStateKind.CHOICE);
			return this;
		}

		public PseudoStateBeingBuilt1 kindEntryPoint() {
			this.myExpr.setKind(miniSC.PseudoStateKind.ENTRY_POINT);
			return this;
		}

		public PseudoStateBeingBuilt1 kindExitPoint() {
			this.myExpr.setKind(miniSC.PseudoStateKind.EXIT_POINT);
			return this;
		}

		public PseudoStateBeingBuilt1 kindTerminate() {
			this.myExpr.setKind(miniSC.PseudoStateKind.TERMINATE);
			return this;
		}
	}

	public interface PseudoStateBeingBuilt0 {
		public PseudoStateBeingBuilt1 name(java.lang.String arg);
	}

	public interface PseudoStateBeingBuilt1 {

		public PseudoStateBeingBuilt1 kindInitial();

		public PseudoStateBeingBuilt1 kindDeepHistory();

		public PseudoStateBeingBuilt1 kindShallowHistory();

		public PseudoStateBeingBuilt1 kindJoin();

		public PseudoStateBeingBuilt1 kindFork();

		public PseudoStateBeingBuilt1 kindJunction();

		public PseudoStateBeingBuilt1 kindChoice();

		public PseudoStateBeingBuilt1 kindEntryPoint();

		public PseudoStateBeingBuilt1 kindExitPoint();

		public PseudoStateBeingBuilt1 kindTerminate();

		/* allModdersAreOptional */
		public miniSC.PseudoState toAST();
	}

	public static class StateBeingBuilt implements StateBeingBuilt0, StateBeingBuilt1, StateBeingBuilt2 {
		private final miniSC.State myExpr;

		public miniSC.State toAST() {
			return this.myExpr;
		}

		StateBeingBuilt(miniSC.State arg) {
			this.myExpr = arg;
		}

		public StateBeingBuilt1 name(java.lang.String arg) {
			this.myExpr.setName(arg);
			return this;
		}

		public StateBeingBuilt2 region(miniSC.Region... items) {
			this.myExpr.getRegion().clear();
			this.myExpr.getRegion().addAll(java.util.Arrays.asList(items));
			return this;
		}
	}

	public interface StateBeingBuilt0 {
		public StateBeingBuilt1 name(java.lang.String arg);
	}

	public interface StateBeingBuilt1 {
		public StateBeingBuilt2 region(miniSC.Region... items);
	}

	public interface StateBeingBuilt2 {
		public miniSC.State toAST();
	}
}