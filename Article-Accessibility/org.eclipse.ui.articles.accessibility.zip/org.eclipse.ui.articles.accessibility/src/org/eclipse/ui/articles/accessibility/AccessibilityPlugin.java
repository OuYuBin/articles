/*******************************************************************************
 * Copyright (c) 2000, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *     Innoopract      - updated for Eclipse 3.x
 *******************************************************************************/
package org.eclipse.ui.articles.accessibility;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * The main plugin class to be used in the desktop.
 */
public class AccessibilityPlugin extends AbstractUIPlugin {
	// The shared instance.
	private static AccessibilityPlugin plugin;
	// plugin id
	private static String PLUGIN_ID = "org.eclipse.ui.articles.accessibility";
	// image constants
	public static String LOGIN_IMAGE = "LOGIN_IMAGE";
	public static String WELCOME_IMAGE = "WELCOME_IMAGE";
	public static String ECLIPSE_IMAGE = "ECLIPSE_IMAGE";

	/**
	 * The constructor.
	 */
	public AccessibilityPlugin() {
		plugin = this;
	}
	
	protected void initializeImageRegistry(ImageRegistry reg) {
		reg.put(LOGIN_IMAGE, getImageDescriptor("icons/namepassword.gif"));
		reg.put(WELCOME_IMAGE, getImageDescriptor("icons/welcome.gif"));
		reg.put(ECLIPSE_IMAGE, getImageDescriptor("icons/eclipse.gif"));
	}

	/**
	 * Returns the shared instance.
	 */
	public static AccessibilityPlugin getDefault() {
		return plugin;
	}
	
	private ImageDescriptor getImageDescriptor(String fileName) {
		ImageDescriptor result = AbstractUIPlugin.imageDescriptorFromPlugin(PLUGIN_ID, fileName);
		if(result == null) {
			result = ImageDescriptor.getMissingImageDescriptor();
		}
		return result;
	}

}
