This is a simple set of projects that represent a simple Phone Book application
for the purposes of demonstrating how to automate the running of Eclipse 3.1
PDE unit tests using ant.

Pre-requisites
==============

You need to install Eclipse 3.1 into a directory called "eclipse-3.1" 
in the "projects" directory where you found this readme.txt file.


Running PDE Tests
=================

To run the PDE unit tests using ant do the following:

C:\...\projects> ant test

This will build the plugins and the PDE unit test fragment, run the tests and generate 
a html report.
