/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.editparts.policies;

import com.metys.merlin.generation.gef.commands.DeleteNodeCommand;

import com.metys.merlin.generation.gef.parts.GraphicalComponentEditPart;

import com.metys.merlin.generation.gef.policies.ENodeComponentEditPolicy;

import org.eclipse.gef.commands.Command;

import org.eclipse.gef.requests.GroupRequest;

import shapes.editparts.ShapeEditPart;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class ShapeComponentEditPolicy extends ENodeComponentEditPolicy{
    
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command createDeleteCommand(GroupRequest deleteRequest) {
    Command deleteCmd = new DeleteNodeCommand((GraphicalComponentEditPart) getHost().getParent(), (ShapeEditPart) getHost());
    return deleteCmd;
  }
}