/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.editparts;

import com.metys.merlin.generation.gef.model.ELink;

import com.metys.merlin.generation.gef.parts.ELinkEditPart;

import org.eclipse.emf.common.notify.AdapterFactory;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public  class ConnectionLinkEditPart extends ELinkEditPart {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConnectionLinkEditPart(ELink model, AdapterFactory adapterFactory) {
    super(model, adapterFactory);
  }
    
}