/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ui.articles.accessibility.views;

import java.net.MalformedURLException;

import org.eclipse.jface.action.*;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.articles.accessibility.AccessibilityPlugin;
import org.eclipse.ui.internal.WorkbenchColors;
import org.eclipse.ui.part.ViewPart;

/**
 * This is a simple example of a view that is the entrance to
 * a website.
 * 
 */

public class EntranceView extends ViewPart {
	private TableViewer viewer;
	private Action resetAction;
	private Action anonymousAction;
	private Text nameEntryField;
	private Text passwordEntryField;

	/**
	 * The constructor.
	 */
	public EntranceView() {
	}

	/**
	 * This is where we create out input controls.
	 */
	public void createPartControl(Composite parent) {

		int offset = 5;
		int endOffset = -5;

		Composite workArea = new Composite(parent, SWT.BORDER);
		FormLayout layout = new FormLayout();
		workArea.setLayout(layout);
		setBackground(workArea);
		Label topLabel = new Label(workArea, SWT.NONE);
		topLabel.setImage(
			AccessibilityPlugin.getDefault().getImageRegistry().get(
				AccessibilityPlugin.LOGIN_IMAGE));

		FormData labelData = new FormData();
		labelData.left = new FormAttachment(0, offset);
		labelData.top = new FormAttachment(0, offset);

		topLabel.setLayoutData(labelData);

		Label titleLabel = new Label(workArea, SWT.NONE);
		setBackground(titleLabel);
		titleLabel.setText("Welcome to our online store!");
		
		FontData labelFontData = new FontData("Arial", 10, SWT.BOLD);
		titleLabel.setFont(new Font(parent.getDisplay(), labelFontData));

		labelData = new FormData();
		labelData.left = new FormAttachment(0, offset);
		labelData.top = new FormAttachment(topLabel, offset);
		
		titleLabel.setLayoutData(labelData);


		Label nameTitle = new Label(workArea, SWT.NONE);
		nameTitle.setText("Name:");
		setBackground(nameTitle);

		labelData = new FormData();
		labelData.left = new FormAttachment(0, offset);
		labelData.top = new FormAttachment(titleLabel, offset);

		nameTitle.setLayoutData(labelData);

		Label passwordTitle = new Label(workArea, SWT.NONE);
		passwordTitle.setText("Password:");
		setBackground(passwordTitle);

		labelData = new FormData();
		labelData.left = new FormAttachment(50, offset);
		labelData.top = new FormAttachment(titleLabel, offset);

		passwordTitle.setLayoutData(labelData);

		nameEntryField = new Text(workArea, SWT.BORDER);

		labelData = new FormData();
		labelData.left = new FormAttachment(0, offset);
		labelData.top = new FormAttachment(nameTitle, offset);
		labelData.right = new FormAttachment(50, endOffset);

		nameEntryField.setLayoutData(labelData);

		passwordEntryField = new Text(workArea, SWT.BORDER);

		labelData = new FormData();
		labelData.left = new FormAttachment(passwordTitle, 0, SWT.LEFT);
		labelData.top = new FormAttachment(passwordTitle, offset);
		labelData.right = new FormAttachment(100, endOffset);

		passwordEntryField.setLayoutData(labelData);

		Button enterButton = new Button(workArea, SWT.PUSH);
		enterButton.setText("Login");

		labelData = new FormData();
		labelData.top = new FormAttachment(nameEntryField, offset);
		labelData.left = new FormAttachment(nameEntryField, 0, SWT.LEFT);
		enterButton.setLayoutData(labelData);

		makeActions();
		contributeToActionBars();
	}
	/**
	 * Set the background color for this view.
	 * @param control
	 */

	private void setBackground(Control control) {
		control.setBackground(WorkbenchColors.getSystemColor(SWT.COLOR_YELLOW));
	}


	/**
	 * Set the text of the actions.
	 *
	 */
	private void setActionText() {
		resetAction.setText("Reset Fields");
		anonymousAction.setText("Anonymous Settings");
	}
	private void makeActions() {
		ImageDescriptor eclipseDescriptor = null;
		try {
			eclipseDescriptor =
				AccessibilityPlugin.getDefault().getImageDescriptor(
					"icons/eclipse.gif");
		} catch (MalformedURLException exception) {
			//If we can't find it don't bother
		}
		resetAction = new Action() {
			public void run() {
				nameEntryField.setText("");
				passwordEntryField.setText("");
			}
		};

		resetAction.setImageDescriptor(eclipseDescriptor);

		anonymousAction = new Action() {
			public void run() {
				nameEntryField.setText("Anonymous");
				passwordEntryField.setText("");
			}
		};
		anonymousAction.setImageDescriptor(eclipseDescriptor);
		setActionText();
	}

	private void contributeToActionBars() {
		IActionBars bars = getViewSite().getActionBars();
		fillLocalPullDown(bars.getMenuManager());
	}

	private void fillLocalPullDown(IMenuManager manager) {
		manager.add(resetAction);
		manager.add(new Separator());
		manager.add(anonymousAction);
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
		nameEntryField.setFocus();
	}
}