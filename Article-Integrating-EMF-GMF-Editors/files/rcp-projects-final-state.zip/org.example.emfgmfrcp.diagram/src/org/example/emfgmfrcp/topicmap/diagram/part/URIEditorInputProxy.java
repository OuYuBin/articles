package org.example.emfgmfrcp.topicmap.diagram.part;

import org.eclipse.emf.common.ui.URIEditorInput;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.ui.IMemento;

/**
 * A simple wrapper to pass an {@link org.eclipse.emf.edit.domain.TransactionalEditingDomain} instance 
 * along with a {@link org.eclipse.emf.common.ui.URIEditorInput}.
 * @author vwegert
 *
 */
public class URIEditorInputProxy extends URIEditorInput {

	protected TransactionalEditingDomain editingDomain;
	
	/**
	 * @param uri
	 */
	public URIEditorInputProxy(URI uri, TransactionalEditingDomain domain) {
		super(uri);
		this.editingDomain = domain;
	}

	/**
	 * @param memento
	 */
	public URIEditorInputProxy(IMemento memento, TransactionalEditingDomain domain) {
		super(memento);
		this.editingDomain = domain;
	}

	/**
	 * @param uri
	 * @param name
	 */
	public URIEditorInputProxy(URI uri, String name, TransactionalEditingDomain domain) {
		super(uri, name);
		this.editingDomain = domain;
	}
	
	/**
	 * @return the editing domain
	 */
	public TransactionalEditingDomain getEditingDomain() {
		return editingDomain;
	}

}
