/**
 * <copyright>
 * </copyright>
 *
 * %W%
 * @version %I% %H%
 */
package com.ibm.example.familytree;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.ibm.example.familytree.FamilytreeFactory
 * @generated
 */
public interface FamilytreePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "familytree";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http:///com/ibm/example/familytree.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "com.ibm.example.familytree";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	FamilytreePackage eINSTANCE = com.ibm.example.familytree.impl.FamilytreePackageImpl.init();

	/**
	 * The meta object id for the '{@link com.ibm.example.familytree.impl.FamilyImpl <em>Family</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.ibm.example.familytree.impl.FamilyImpl
	 * @see com.ibm.example.familytree.impl.FamilytreePackageImpl#getFamily()
	 * @generated
	 */
	int FAMILY = 0;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAMILY__CHILDREN = 0;

	/**
	 * The feature id for the '<em><b>Mother</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAMILY__MOTHER = 1;

	/**
	 * The feature id for the '<em><b>Father</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAMILY__FATHER = 2;

	/**
	 * The number of structural features of the the '<em>Family</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAMILY_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link com.ibm.example.familytree.impl.FamilyTreeImpl <em>Family Tree</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.ibm.example.familytree.impl.FamilyTreeImpl
	 * @see com.ibm.example.familytree.impl.FamilytreePackageImpl#getFamilyTree()
	 * @generated
	 */
	int FAMILY_TREE = 1;

	/**
	 * The feature id for the '<em><b>Families</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAMILY_TREE__FAMILIES = 0;

	/**
	 * The feature id for the '<em><b>Individuals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAMILY_TREE__INDIVIDUALS = 1;

	/**
	 * The number of structural features of the the '<em>Family Tree</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAMILY_TREE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link com.ibm.example.familytree.impl.IndividualImpl <em>Individual</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.ibm.example.familytree.impl.IndividualImpl
	 * @see com.ibm.example.familytree.impl.FamilytreePackageImpl#getIndividual()
	 * @generated
	 */
	int INDIVIDUAL = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDIVIDUAL__NAME = 0;

	/**
	 * The number of structural features of the the '<em>Individual</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDIVIDUAL_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link com.ibm.example.familytree.impl.FemaleImpl <em>Female</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.ibm.example.familytree.impl.FemaleImpl
	 * @see com.ibm.example.familytree.impl.FamilytreePackageImpl#getFemale()
	 * @generated
	 */
	int FEMALE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEMALE__NAME = INDIVIDUAL__NAME;

	/**
	 * The number of structural features of the the '<em>Female</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEMALE_FEATURE_COUNT = INDIVIDUAL_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.ibm.example.familytree.impl.MaleImpl <em>Male</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.ibm.example.familytree.impl.MaleImpl
	 * @see com.ibm.example.familytree.impl.FamilytreePackageImpl#getMale()
	 * @generated
	 */
	int MALE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MALE__NAME = INDIVIDUAL__NAME;

	/**
	 * The number of structural features of the the '<em>Male</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MALE_FEATURE_COUNT = INDIVIDUAL_FEATURE_COUNT + 0;


	/**
	 * Returns the meta object for class '{@link com.ibm.example.familytree.Family <em>Family</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Family</em>'.
	 * @see com.ibm.example.familytree.Family
	 * @generated
	 */
	EClass getFamily();

	/**
	 * Returns the meta object for the containment reference list '{@link com.ibm.example.familytree.Family#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Children</em>'.
	 * @see com.ibm.example.familytree.Family#getChildren()
	 * @see #getFamily()
	 * @generated
	 */
	EReference getFamily_Children();

	/**
	 * Returns the meta object for the reference '{@link com.ibm.example.familytree.Family#getMother <em>Mother</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Mother</em>'.
	 * @see com.ibm.example.familytree.Family#getMother()
	 * @see #getFamily()
	 * @generated
	 */
	EReference getFamily_Mother();

	/**
	 * Returns the meta object for the reference '{@link com.ibm.example.familytree.Family#getFather <em>Father</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Father</em>'.
	 * @see com.ibm.example.familytree.Family#getFather()
	 * @see #getFamily()
	 * @generated
	 */
	EReference getFamily_Father();

	/**
	 * Returns the meta object for class '{@link com.ibm.example.familytree.FamilyTree <em>Family Tree</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Family Tree</em>'.
	 * @see com.ibm.example.familytree.FamilyTree
	 * @generated
	 */
	EClass getFamilyTree();

	/**
	 * Returns the meta object for the containment reference list '{@link com.ibm.example.familytree.FamilyTree#getFamilies <em>Families</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Families</em>'.
	 * @see com.ibm.example.familytree.FamilyTree#getFamilies()
	 * @see #getFamilyTree()
	 * @generated
	 */
	EReference getFamilyTree_Families();

	/**
	 * Returns the meta object for the containment reference list '{@link com.ibm.example.familytree.FamilyTree#getIndividuals <em>Individuals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Individuals</em>'.
	 * @see com.ibm.example.familytree.FamilyTree#getIndividuals()
	 * @see #getFamilyTree()
	 * @generated
	 */
	EReference getFamilyTree_Individuals();

	/**
	 * Returns the meta object for class '{@link com.ibm.example.familytree.Female <em>Female</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Female</em>'.
	 * @see com.ibm.example.familytree.Female
	 * @generated
	 */
	EClass getFemale();

	/**
	 * Returns the meta object for class '{@link com.ibm.example.familytree.Individual <em>Individual</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Individual</em>'.
	 * @see com.ibm.example.familytree.Individual
	 * @generated
	 */
	EClass getIndividual();

	/**
	 * Returns the meta object for the attribute '{@link com.ibm.example.familytree.Individual#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see com.ibm.example.familytree.Individual#getName()
	 * @see #getIndividual()
	 * @generated
	 */
	EAttribute getIndividual_Name();

	/**
	 * Returns the meta object for class '{@link com.ibm.example.familytree.Male <em>Male</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Male</em>'.
	 * @see com.ibm.example.familytree.Male
	 * @generated
	 */
	EClass getMale();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	FamilytreeFactory getFamilytreeFactory();

} //FamilytreePackage
