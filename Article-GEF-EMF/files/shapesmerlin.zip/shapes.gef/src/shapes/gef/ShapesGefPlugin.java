
/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package shapes.gef;

import org.eclipse.ui.plugin.AbstractUIPlugin;

import java.net.MalformedURLException;
import java.net.URL;


/**
 * GEF Plugin class.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class ShapesGefPlugin extends AbstractUIPlugin {
  
  private static ShapesGefPlugin plugin;
  
  /**
   * Returns the singleton instance of the Eclipse plugin.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the singleton instance.
   * @generated
   */
  public static ShapesGefPlugin getPlugin() {
    return plugin;
  }
  
  /**
   * Creates a new ShapesPlugin
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ShapesGefPlugin() {
    super();
    plugin = this;
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */	
  public URL getResource(String resourcePath) {
    try {
      URL url = new URL(getBundle().getEntry("/") + resourcePath);
      return url;
    } catch (MalformedURLException e) {		
    }
    return null;
  }
}