package org.example.emfgmf.topicmap.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;
import org.example.emfgmf.topicmap.diagram.part.TopicMapDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	 * @generated
	 */
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(TopicMapDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
