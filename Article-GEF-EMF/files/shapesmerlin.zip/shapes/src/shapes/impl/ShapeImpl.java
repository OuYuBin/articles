/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package shapes.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import shapes.Connection;
import shapes.Shape;
import shapes.ShapesPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Shape</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link shapes.impl.ShapeImpl#getX <em>X</em>}</li>
 *   <li>{@link shapes.impl.ShapeImpl#getY <em>Y</em>}</li>
 *   <li>{@link shapes.impl.ShapeImpl#getWidth <em>Width</em>}</li>
 *   <li>{@link shapes.impl.ShapeImpl#getHeight <em>Height</em>}</li>
 *   <li>{@link shapes.impl.ShapeImpl#getSourceConnections <em>Source Connections</em>}</li>
 *   <li>{@link shapes.impl.ShapeImpl#getTargetConnections <em>Target Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class ShapeImpl extends EObjectImpl implements Shape {
  /**
   * The default value of the '{@link #getX() <em>X</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getX()
   * @generated
   * @ordered
   */
  protected static final int X_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getX() <em>X</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getX()
   * @generated
   * @ordered
   */
  protected int x = X_EDEFAULT;

  /**
   * The default value of the '{@link #getY() <em>Y</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getY()
   * @generated
   * @ordered
   */
  protected static final int Y_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getY() <em>Y</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getY()
   * @generated
   * @ordered
   */
  protected int y = Y_EDEFAULT;

  /**
   * The default value of the '{@link #getWidth() <em>Width</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidth()
   * @generated
   * @ordered
   */
  protected static final int WIDTH_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getWidth() <em>Width</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidth()
   * @generated
   * @ordered
   */
  protected int width = WIDTH_EDEFAULT;

  /**
   * The default value of the '{@link #getHeight() <em>Height</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeight()
   * @generated
   * @ordered
   */
  protected static final int HEIGHT_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getHeight() <em>Height</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeight()
   * @generated
   * @ordered
   */
  protected int height = HEIGHT_EDEFAULT;

  /**
   * The cached value of the '{@link #getSourceConnections() <em>Source Connections</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSourceConnections()
   * @generated
   * @ordered
   */
  protected EList sourceConnections = null;

  /**
   * The cached value of the '{@link #getTargetConnections() <em>Target Connections</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetConnections()
   * @generated
   * @ordered
   */
  protected EList targetConnections = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ShapeImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return ShapesPackage.eINSTANCE.getShape();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getX() {
    return x;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setX(int newX) {
    int oldX = x;
    x = newX;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ShapesPackage.SHAPE__X, oldX, x));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getY() {
    return y;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setY(int newY) {
    int oldY = y;
    y = newY;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ShapesPackage.SHAPE__Y, oldY, y));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getWidth() {
    return width;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setWidth(int newWidth) {
    int oldWidth = width;
    width = newWidth;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ShapesPackage.SHAPE__WIDTH, oldWidth, width));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getHeight() {
    return height;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHeight(int newHeight) {
    int oldHeight = height;
    height = newHeight;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ShapesPackage.SHAPE__HEIGHT, oldHeight, height));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getSourceConnections() {
    if (sourceConnections == null) {
      sourceConnections = new EObjectContainmentWithInverseEList(Connection.class, this, ShapesPackage.SHAPE__SOURCE_CONNECTIONS, ShapesPackage.CONNECTION__SOURCE);
    }
    return sourceConnections;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getTargetConnections() {
    if (targetConnections == null) {
      targetConnections = new EObjectWithInverseResolvingEList(Connection.class, this, ShapesPackage.SHAPE__TARGET_CONNECTIONS, ShapesPackage.CONNECTION__TARGET);
    }
    return targetConnections;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ShapesPackage.SHAPE__SOURCE_CONNECTIONS:
          return ((InternalEList)getSourceConnections()).basicAdd(otherEnd, msgs);
        case ShapesPackage.SHAPE__TARGET_CONNECTIONS:
          return ((InternalEList)getTargetConnections()).basicAdd(otherEnd, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ShapesPackage.SHAPE__SOURCE_CONNECTIONS:
          return ((InternalEList)getSourceConnections()).basicRemove(otherEnd, msgs);
        case ShapesPackage.SHAPE__TARGET_CONNECTIONS:
          return ((InternalEList)getTargetConnections()).basicRemove(otherEnd, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.SHAPE__X:
        return new Integer(getX());
      case ShapesPackage.SHAPE__Y:
        return new Integer(getY());
      case ShapesPackage.SHAPE__WIDTH:
        return new Integer(getWidth());
      case ShapesPackage.SHAPE__HEIGHT:
        return new Integer(getHeight());
      case ShapesPackage.SHAPE__SOURCE_CONNECTIONS:
        return getSourceConnections();
      case ShapesPackage.SHAPE__TARGET_CONNECTIONS:
        return getTargetConnections();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.SHAPE__X:
        setX(((Integer)newValue).intValue());
        return;
      case ShapesPackage.SHAPE__Y:
        setY(((Integer)newValue).intValue());
        return;
      case ShapesPackage.SHAPE__WIDTH:
        setWidth(((Integer)newValue).intValue());
        return;
      case ShapesPackage.SHAPE__HEIGHT:
        setHeight(((Integer)newValue).intValue());
        return;
      case ShapesPackage.SHAPE__SOURCE_CONNECTIONS:
        getSourceConnections().clear();
        getSourceConnections().addAll((Collection)newValue);
        return;
      case ShapesPackage.SHAPE__TARGET_CONNECTIONS:
        getTargetConnections().clear();
        getTargetConnections().addAll((Collection)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.SHAPE__X:
        setX(X_EDEFAULT);
        return;
      case ShapesPackage.SHAPE__Y:
        setY(Y_EDEFAULT);
        return;
      case ShapesPackage.SHAPE__WIDTH:
        setWidth(WIDTH_EDEFAULT);
        return;
      case ShapesPackage.SHAPE__HEIGHT:
        setHeight(HEIGHT_EDEFAULT);
        return;
      case ShapesPackage.SHAPE__SOURCE_CONNECTIONS:
        getSourceConnections().clear();
        return;
      case ShapesPackage.SHAPE__TARGET_CONNECTIONS:
        getTargetConnections().clear();
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ShapesPackage.SHAPE__X:
        return x != X_EDEFAULT;
      case ShapesPackage.SHAPE__Y:
        return y != Y_EDEFAULT;
      case ShapesPackage.SHAPE__WIDTH:
        return width != WIDTH_EDEFAULT;
      case ShapesPackage.SHAPE__HEIGHT:
        return height != HEIGHT_EDEFAULT;
      case ShapesPackage.SHAPE__SOURCE_CONNECTIONS:
        return sourceConnections != null && !sourceConnections.isEmpty();
      case ShapesPackage.SHAPE__TARGET_CONNECTIONS:
        return targetConnections != null && !targetConnections.isEmpty();
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (x: ");
    result.append(x);
    result.append(", y: ");
    result.append(y);
    result.append(", width: ");
    result.append(width);
    result.append(", height: ");
    result.append(height);
    result.append(')');
    return result.toString();
  }

} //ShapeImpl
