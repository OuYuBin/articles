package org.eclipse.ui.articles.accessibility;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * The main plugin class to be used in the desktop.
 */
public class AccessibilityPlugin extends AbstractUIPlugin {
	//The shared instance.
	private static AccessibilityPlugin plugin;
	//Resource bundle.
	private ResourceBundle resourceBundle;
	//constants
	public static String LOGIN_IMAGE = "LOGIN_IMAGE";
	public static String WELCOME_IMAGE = "WELCOME_IMAGE";

	/**
	 * The constructor.
	 */
	public AccessibilityPlugin(IPluginDescriptor descriptor) {
		super(descriptor);
		plugin = this;
		try {
			resourceBundle =
				ResourceBundle.getBundle(
					"org.eclipse.ui.articles.accessibility.AccessibilityPluginResources");
		} catch (MissingResourceException x) {
			resourceBundle = null;
		}

		try {
			getImageRegistry().put(
				LOGIN_IMAGE,
				getImageDescriptor("icons/namepassword.gif"));
			getImageRegistry().put(
				WELCOME_IMAGE,
				getImageDescriptor("icons/welcome.gif"));
		} catch (MalformedURLException exception) {
		}
	}

	public ImageDescriptor getImageDescriptor(String fileName) throws MalformedURLException {
		return ImageDescriptor.createFromURL(
			new URL(getDescriptor().getInstallURL(), fileName));
	}

	/**
	 * Returns the shared instance.
	 */
	public static AccessibilityPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns the workspace instance.
	 */
	public static IWorkspace getWorkspace() {
		return ResourcesPlugin.getWorkspace();
	}

	/**
	 * Returns the string from the plugin's resource bundle,
	 * or 'key' if not found.
	 */
	public static String getResourceString(String key) {
		ResourceBundle bundle =
			AccessibilityPlugin.getDefault().getResourceBundle();
		try {
			return bundle.getString(key);
		} catch (MissingResourceException e) {
			return key;
		}
	}

	/**
	 * Returns the plugin's resource bundle,
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
}
